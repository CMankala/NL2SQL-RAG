# benchmark

Scripts and metadata for the evaluation set described in Sec. IV-A of the paper.

| Item | Contents |
|---|---|
| Schema extraction | Scripts that extract the 143 schemas from BIRD and Spider |
| Schema scaling | Scripts that build the 10-, 50- and 120-table configurations |
| Data synthesis | Scripts that populate tables with distribution-matching synthetic data |
| Question set | The 1,500 questions (500 BIRD, 500 Spider, 500 human-written) with gold SQL |

The BIRD and Spider source data are not redistributed here; download them from their original sources (see the top-level README).
