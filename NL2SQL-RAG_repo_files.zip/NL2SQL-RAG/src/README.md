# src

Pipeline implementation. Suggested layout, matching the paper's three layers:

| Folder | Paper section | Contents |
|---|---|---|
| `retrieval/` | III-A | Dense and BM25 indexing, entropy-weighted hybrid scoring, Collective Schema Subsetting (Algorithm 1) |
| `gateway/` | III-B, III-D | MCP server and tool schemas, JSON-schema logit masking |
| `compiler/` | III-C | GL-SL schema linking and AST-to-SQL compilation |
| `orchestration/` | III-E | LangGraph state machine and retry routing |
| `eval/` | IV | EX, VES, SER and SHR computation; baseline runners |
