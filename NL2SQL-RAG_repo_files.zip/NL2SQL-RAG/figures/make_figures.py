"""Regenerate Figs. 2 and 4 of the paper from the CSV files in results/.

Usage (from the repository root):
    python figures/make_figures.py
"""
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import FixedFormatter, FixedLocator, NullLocator

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
OUT = ROOT / "figures"

INK, GRID = "#0b0b0b", "#e1e0d9"
plt.rcParams.update({
    "font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 8,
    "axes.linewidth": 0.6, "axes.edgecolor": "#898781",
    "xtick.color": "#52514e", "ytick.color": "#52514e", "axes.labelcolor": INK,
    "xtick.major.width": 0.5, "ytick.major.width": 0.5, "pdf.fonttype": 42,
})

# system -> (legend label, colour, marker, line style)
STYLE = {
    "Proposed MCP+RAG": ("Proposed MCP+RAG", "#2a78d6", "o", "-"),
    "MCP-Only (no RAG)": ("MCP-Only (no RAG)", "#eb6834", "s", "--"),
    "LinkAlign": ("LinkAlign", "#1baf7a", "^", "-."),
    "RSL-SQL": ("RSL-SQL", "#eda100", "D", ":"),
    "Ungoverned Baseline": ("Ungoverned", "#e87ba4", "v", (0, (5, 1, 1, 1))),
}
LOG_FLOOR = 0.1  # zero cannot be drawn on a log axis


def read_csv(name):
    with open(RESULTS / name, newline="") as f:
        return list(csv.DictReader(f))


def style_axis(ax):
    ax.grid(axis="y", color=GRID, lw=0.5)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.tick_params(length=2, pad=2)


def fig_scaling():
    rows = read_csv("table1_schema_scaling.csv")
    fig, (a, b) = plt.subplots(1, 2, figsize=(3.5, 2.05))
    for system, (label, color, marker, ls) in STYLE.items():
        pts = sorted((r for r in rows if r["system"] == system), key=lambda r: int(r["tables"]))
        x = [int(r["tables"]) for r in pts]
        ex = [float(r["ex_pct"]) for r in pts]
        shr = [float(r["shr_pct"]) for r in pts]
        lw = 2.0 if system.startswith("Proposed") else 1.3
        kw = dict(color=color, ls=ls, lw=lw, ms=4.5, mew=0.6)
        a.plot(x, ex, marker=marker, mec="white", label=label, zorder=3, **kw)
        b.plot(x, [max(v, LOG_FLOOR) for v in shr], zorder=2, **{k: kw[k] for k in ("color", "ls", "lw")})
        for xi, v in zip(x, shr):
            if v > 0:
                b.plot([xi], [v], marker=marker, color=color, mec="white", ms=4.5, mew=0.6, zorder=3)
            else:  # zero observed events: hollow marker at the axis floor
                b.plot([xi], [LOG_FLOOR], marker=marker, mfc="white", mec=color, ms=4.5, mew=1.0, zorder=4)
    for ax in (a, b):
        ax.set_xticks([10, 50, 120])
        ax.set_xlim(0, 130)
        style_axis(ax)
    a.set_ylim(40, 100)
    a.set_ylabel("Execution accuracy (%)", labelpad=1)
    a.set_xlabel("(a) Tables in schema", labelpad=1)
    b.set_yscale("log")
    b.set_ylim(0.07, 60)
    b.set_ylabel("SHR (%, log scale)", labelpad=1)
    b.set_xlabel("(b) Tables in schema", labelpad=1)
    b.yaxis.set_major_locator(FixedLocator([0.1, 0.3, 1, 3, 10, 30]))
    b.yaxis.set_major_formatter(FixedFormatter(["0.1", "0.3", "1", "3", "10", "30"]))
    b.yaxis.set_minor_locator(NullLocator())
    handles, labels = a.get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=3, frameon=False, fontsize=6.6,
               handlelength=2.4, columnspacing=0.9, handletextpad=0.4,
               bbox_to_anchor=(0.5, 1.0), labelcolor=INK)
    fig.subplots_adjust(left=0.115, right=0.99, bottom=0.17, top=0.82, wspace=0.42)
    fig.savefig(OUT / "fig_scaling.pdf")


def fig_evolution():
    rows = read_csv("fig4_schema_evolution.csv")
    cats = [r["perturbation"].replace(" ", "\n") for r in rows]
    ex = [float(r["ex_pct"]) for r in rows]
    shr = [float(r["shr_pct"]) for r in rows]
    i = np.arange(len(rows))
    fig, (a, b) = plt.subplots(1, 2, figsize=(3.5, 1.75))
    panels = ((a, ex, "#2a78d6", "Execution accuracy (%)", 105, "(a) Perturbation"),
              (b, shr, "#eb6834", "SHR (%)", 21, "(b) Perturbation"))
    for ax, vals, color, ylabel, ymax, xlabel in panels:
        ax.bar(i, vals, 0.62, color=color, zorder=3)
        for xi, v in zip(i, vals):
            ax.text(xi, v + ymax * 0.015, f"{v}", ha="center", va="bottom", fontsize=7, color=INK)
        ax.set_xticks(i)
        ax.set_xticklabels(cats, fontsize=6.5, color=INK)
        ax.set_ylim(0, ymax)
        ax.set_ylabel(ylabel, labelpad=1)
        ax.set_xlabel(xlabel, labelpad=1)
        style_axis(ax)
        ax.tick_params(axis="x", length=0)
    b.axhline(15, color="#52514e", ls=":", lw=0.9, zorder=4)
    b.text(-0.42, 15.4, "15% risk threshold", fontsize=6.5, color="#52514e", ha="left", va="bottom")
    fig.subplots_adjust(left=0.115, right=0.99, bottom=0.3, top=0.95, wspace=0.42)
    fig.savefig(OUT / "fig_evolution.pdf")


if __name__ == "__main__":
    fig_scaling()
    fig_evolution()
    print("Wrote", OUT / "fig_scaling.pdf", "and", OUT / "fig_evolution.pdf")
