# NL2SQL-RAG

Companion repository for the paper

> C. K. Mankala and M. Giacobbe, "Making Enterprise NL2SQL Reliable: MCP, Constrained Decoding, and Hybrid RAG," in *Proc. Int. Conf. on Artificial Intelligence, Computer, Data Sciences and Applications (ACDSA 2027)*, Rio de Janeiro, Brazil, Feb. 2027.

The paper presents an enterprise NL2SQL pipeline in which the LLM never writes SQL:

1. **Semantic orchestration** – entropy-guided sparse–dense hybrid retrieval and Collective Schema Subsetting (CSS) select the part of the schema a question needs.
2. **Protocol gateway** – a Model Context Protocol (MCP) gateway constrains decoding with JSON-schema masks, so the model emits only valid tool invocations.
3. **Deterministic execution** – an AST compiler turns each validated invocation into parameterized ANSI SQL.

## Repository layout

| Path | Contents |
|---|---|
| `src/` | Pipeline implementation (retrieval and CSS, MCP gateway and logit masking, AST compiler, LangGraph orchestration) |
| `benchmark/` | Scripts that build the 10-, 50- and 120-table configurations from BIRD and Spider, and the question set |
| `results/` | Reported results as CSV files, one per table or figure in the paper |
| `figures/` | Script that regenerates Figs. 2 and 4 from `results/`, and the generated PDFs |
| `CITATION.cff` | Citation metadata |

## Reported results

The CSV files in `results/` contain the numbers reported in the paper.

| File | Paper item |
|---|---|
| `results/table1_schema_scaling.csv` | Table I – EX, VES, SER and SHR for five systems at 10, 50 and 120 tables |
| `results/table2_ablation.csv` | Table II – ablation at 120 tables |
| `results/table3_latency.csv` | Table III – median stage latency at 120 tables |
| `results/fig4_schema_evolution.csv` | Fig. 4 – EX and SHR under schema perturbation |

Headline result at 120 tables (1,500 questions): 91.4% execution accuracy for the proposed pipeline, versus 68.2% for LinkAlign and 49.1% for an ungoverned baseline.

## Regenerating the figures

```bash
pip install -r requirements.txt
python figures/make_figures.py
```

This writes `figures/fig_scaling.pdf` (Fig. 2) and `figures/fig_evolution.pdf` (Fig. 4).

## Data

The evaluation set is derived from two public benchmarks, which must be obtained from their original sources:

- BIRD: https://bird-bench.github.io
- Spider: https://yale-lily.github.io/spider

## Limitations

The paper's Sec. VI-B lists the limits of the evaluation, including the single LLM (Qwen2.5-Coder-32B-Instruct), the pre-engineered tool catalog, and the absence of comparisons with off-the-shelf constrained-decoding engines.

## Citation

See `CITATION.cff`, or use:

```bibtex
@inproceedings{mankala2027nl2sql,
  author    = {Mankala, Chaitanya Kumar and Giacobbe, Maurizio},
  title     = {Making Enterprise {NL2SQL} Reliable: {MCP}, Constrained Decoding, and Hybrid {RAG}},
  booktitle = {Proc. Int. Conf. on Artificial Intelligence, Computer, Data Sciences and Applications (ACDSA)},
  address   = {Rio de Janeiro, Brazil},
  year      = {2027}
}
```

## Acknowledgment

This work used the Augie High-Performance Computing cluster at Villanova University, funded by National Science Foundation award 2018933.
