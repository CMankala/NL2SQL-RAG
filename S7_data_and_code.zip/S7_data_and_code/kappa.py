"""Cohen's kappa between the lead reviewer and the second coder, per field.
Usage: python kappa.py lead.csv second.csv  (both keyed by 'rid')."""
import csv, sys
from collections import Counter

def kappa(a, b):
    n = len(a)
    if n == 0:
        return float('nan'), 0, float('nan')
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / (n * n)
    k = (po - pe) / (1 - pe) if pe < 1 else 1.0
    return k, n, po

def load(p):
    if p.endswith('.xlsx'):
        from openpyxl import load_workbook
        ws=load_workbook(p,read_only=True).active; it=ws.iter_rows(values_only=True); h=[str(x) for x in next(it)]
        return {str(r[0]):{h[i]:('' if v is None else str(v)) for i,v in enumerate(r)} for r in it if r[0]}
    with open(p, newline='', encoding='utf-8') as f:
        return {r['rid']: r for r in csv.DictReader(f)}

if __name__ == '__main__':
    L, S = load(sys.argv[1]), load(sys.argv[2])
    ids = sorted(set(L) & set(S))
    fields = [c for c in next(iter(S.values())).keys() if c not in ('rid', 'title', 'abstract', 'link', 'notes', 'venue', 'comment')]
    print(f'records in both sheets: {len(ids)}')
    for c in fields:
        pairs = [(L[i].get(c, '').strip(), S[i].get(c, '').strip()) for i in ids
                 if L[i].get(c, '').strip() and S[i].get(c, '').strip()]
        if not pairs:
            continue
        k, n, po = kappa([p[0] for p in pairs], [p[1] for p in pairs])
        print(f'{c:20s} n={n:4d}  agreement={po:.2f}  kappa={k:.2f}')
    # screening: include vs not (I/U counted as include for the full-text decision)
    if 'decision' in fields:
        pairs = [(L[i]['decision'] in ('I', 'U'), S[i]['decision'] in ('I', 'U')) for i in ids]
        k, n, po = kappa([p[0] for p in pairs], [p[1] for p in pairs])
        print(f'{"include(I/U) vs X":20s} n={n:4d}  agreement={po:.2f}  kappa={k:.2f}')
