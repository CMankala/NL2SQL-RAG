"""Rule-based pre-screen (documented in Methods). A record passes if its title+abstract contains
(i) an LLM term, (ii) a multi-agent term, as whole phrases (the arXiv API matches loosely), and
(iii) its title does not mark it as a secondary study. Reasons are recorded."""
import json,re,sys,csv
LLM=re.compile(r'\b(large language models?|language models?|LLMs?|GPT[-\s]?\d*\w*|ChatGPT|foundation models?|generative AI|vision[- ]language models?|VLMs?)\b',re.I)
MAS=re.compile(r'\b(multi[- ]?agents?|multiagent|multiple (LLM |AI |language[- ]model |autonomous )?agents|agent collaboration|collaborating agents|collaborative agents|agent teams?|team of agents|multi[- ]?robots?|multirobot|multi[- ]?UAVs?|agentic workflows?)\b',re.I)
SEC=re.compile(r'\b(survey|review|overview|perspective|position paper|vision paper|tutorial|roadmap|state of the art|state-of-the-art review|systematic mapping|bibliometric)\b',re.I)
def screen(r):
    t=r['title']; ta=t+' '+r['abstract']
    if not LLM.search(ta): return 'PS1 no LLM term'
    if not MAS.search(ta): return 'PS2 no multi-agent term'
    if SEC.search(t): return 'PS3 secondary study (title)'
    return ''
if __name__=='__main__':
    recs=json.load(open(sys.argv[1])); out=sys.argv[2]
    n={}
    with open(out,'w',newline='') as f:
        w=csv.writer(f); w.writerow(['rid','source','title','prescreen'])
        for r in recs:
            s=screen(r); r['prescreen']=s; n[s]=n.get(s,0)+1
            w.writerow([r['rid'],r['source'],r['title'],s])
    json.dump(recs,open(sys.argv[1],'w'))
    print(n)
