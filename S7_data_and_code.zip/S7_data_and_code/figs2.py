"""Additional figures for the ESWA manuscript. All values computed from the released coding file."""
import csv, json, math, collections, re
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
B="/home/claude/p1s"; OUT=f"{B}/analysis"
R=json.load(open(f"{OUT}/results.json"))
I=[r for r in csv.DictReader(open(f"{B}/fulltext/coded_all_final.csv")) if r["ft_decision"]=="I"]
cand={r["rid"]:r for r in csv.DictReader(open(f"{B}/screen/fulltext_candidates_all.csv"))}
ax_={r["rid"]:r for r in json.load(open(f"{B}/search/arxiv_records.json"))}
oa={r["rid"]:r for r in json.load(open(f"{B}/search/openalex_dedup.json"))}
INK,INK2,GRID="#0B0B0B","#52514E","#E1E0D9"; S1,S2="#2a78d6","#eb6834"; BLUE=["#86B6EF","#5598E7","#256ABF","#104281"]
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8,"axes.edgecolor":INK2,"axes.labelcolor":INK,"xtick.color":INK2,"ytick.color":INK2,"axes.spines.top":False,"axes.spines.right":False})
def wilson(k,n,z=1.96):
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return p,c-h,c+h
yn=lambda r,k: r[k].strip().upper().startswith("Y")
X={}
# ---- Fig growth: (a) per year by source, (b) per quarter, log scale with fit
q=collections.Counter(); nodate=0
for r in I:
    d=ax_[r["rid"]]["published"][:10] if r["rid"] in ax_ else (oa[r["rid"]].get("date") if r["rid"] in oa else None)
    if not d: nodate+=1; continue
    y,m=int(d[:4]),int(d[5:7]); q[(y,(m-1)//3+1)]+=1
qs=[(y,k) for y in (2023,2024,2025,2026) for k in (1,2,3,4) if (y,k)<=(2026,4)]
vals=[q.get(k,0) for k in qs]
fitq=[k for k in qs if (2024,1)<=k<=(2026,3)]; xs=np.array([qs.index(k) for k in fitq]); ys=np.array([q.get(k,0) for k in fitq],float)
b,a=np.polyfit(xs,np.log(ys),1); dbl=math.log(2)/b*3
resid=np.log(ys)-(a+b*xs); r2=1-resid.var()/np.log(ys).var()
X["growth"]={"no_quarter_date":nodate,"quarterly":{f"{y}Q{k}":q.get((y,k),0) for y,k in qs},"fit_quarters":f"{fitq[0]}–{fitq[-1]}","doubling_months":dbl,"r2":r2,"growth_per_quarter":math.exp(b)-1}
fig,(a1,a2)=plt.subplots(1,2,figsize=(6.8,2.7),gridspec_kw={"width_ratios":[1,1.5]})
yrs=["2023","2024","2025","2026"]; A=[R["year_stream"]["arXiv"].get(y,0) for y in yrs]; J=[R["year_stream"]["Journal/conference"].get(y,0) for y in yrs]
a1.bar(yrs,A,color=S1,width=0.62,label="arXiv",edgecolor="white",linewidth=1,zorder=2); a1.bar(yrs,J,bottom=A,color=S2,width=0.62,label="Journal/conference",edgecolor="white",linewidth=1,zorder=2)
for i,(p_,q_) in enumerate(zip(A,J)): a1.text(i,p_+q_+4,str(p_+q_),ha="center",fontsize=7.5,color=INK)
a1.set_ylabel("Included studies"); a1.yaxis.grid(True,color=GRID,zorder=0); a1.legend(frameon=False,fontsize=6.5,loc="upper left"); a1.set_title("(a) By year and source",fontsize=8,loc="left",color=INK)
xx=np.arange(len(qs)); nz=[(i,v) for i,v in enumerate(vals) if v>0]
part=qs.index((2026,4))
a2.plot([i for i,v in nz if i!=part],[v for i,v in nz if i!=part],"o-",color=S1,lw=2,ms=5,zorder=3,label="Studies per quarter")
if vals[part]>0: a2.plot([part],[vals[part]],"o",mfc="white",mec=S1,ms=5,zorder=3,label="2026 Q4 (to 7 Nov, partial)")
fx=np.linspace(xs[0],xs[-1],50); a2.plot(fx,np.exp(a+b*fx),"--",color=INK2,lw=1,zorder=2,label=f"Exponential fit (doubling every {dbl:.1f} months)")
a2.set_yscale("log"); a2.set_xticks(xx); a2.set_xticklabels([f"Q{k}\n{y}" if k==1 else f"Q{k}" for y,k in qs],fontsize=6.5)
a2.yaxis.grid(True,color=GRID,zorder=0); a2.set_ylabel("Included studies (log scale)"); a2.legend(frameon=False,fontsize=6.5,loc="upper left"); a2.set_title("(b) By quarter, logarithmic scale",fontsize=8,loc="left",color=INK)
a2.set_yticks([1,3,10,30,100]); a2.set_yticklabels(["1","3","10","30","100"])
fig.tight_layout(); fig.savefig(f"{OUT}/fig_growth.pdf"); fig.savefig(f"{OUT}/fig_growth.png",dpi=300); plt.close(fig)

# ---- Fig funnel (log): selection and attribution
sel=[("Records identified",9687),("Unique records",7029),("Screened on title and abstract",6287),("Full text sought",1376),("Full text assessed",610),("Studies included",373)]
n=len(I); k_any=sum(1 for r in I if r["evidence_tier"] in ("E2","E3")); k_sb=sum(yn(r,"baseline_single") for r in I); k_mb=sum(yn(r,"matched_budget") for r in I)
k_mbrep=sum(yn(r,"matched_budget") and yn(r,"repeated_runs_yn") for r in I); k_mbst=sum(yn(r,"matched_budget") and yn(r,"stats_test") for r in I)
att=[("Included studies",n),("Any comparison or ablation (E2–E3)",k_any),("Single-agent baseline",k_sb),("Matched single-agent baseline",k_mb),("Matched + repeated runs",k_mbrep),("Matched + inferential statistics",k_mbst)]
X["funnel"]={"selection":sel,"attribution":att}
fig,(a1,a2)=plt.subplots(1,2,figsize=(6.8,2.6))
for ax,data,col,title in ((a1,sel,INK2,"(a) Selection of studies"),(a2,att,S1,"(b) Attribution evidence")):
    lab=[d[0] for d in data][::-1]; v=[d[1] for d in data][::-1]
    ax.barh(lab,v,color=col if ax is a2 else "#898781",height=0.6,zorder=2); ax.set_xscale("log"); ax.set_xlim(1,60000 if ax is a1 else 2500)
    for i,x in enumerate(v): ax.text(x*1.15,i,f"{x:,}"+("" if ax is a1 else f" ({100*x/n:.1f}%)"),va="center",fontsize=7,color=INK)
    ax.xaxis.grid(True,color=GRID,zorder=0); ax.tick_params(axis="y",length=0,labelsize=7); ax.set_title(title,fontsize=8,loc="left",color=INK); ax.set_xlabel("Count (log scale)")
fig.tight_layout(); fig.savefig(f"{OUT}/fig_funnel.pdf"); fig.savefig(f"{OUT}/fig_funnel.png",dpi=300); plt.close(fig)

# ---- Fig trend: criteria by period with Wilson CI
cand_y={r["rid"]:str(cand[r["rid"]]["year"])[:4] for r in I}
per=[("2023–2024",lambda y:y<="2024"),("2025",lambda y:y=="2025"),("2026",lambda y:y=="2026")]
crit=[("Ablation","ablation_yn"),("Single-agent baseline","baseline_single"),("Repeated runs","repeated_runs_yn"),("Matched budget","matched_budget"),("Inferential statistics","stats_test")]
X["trend"]={}
fig,axs=plt.subplots(1,5,figsize=(6.8,2.1),sharey=True)
for ax,(name,key) in zip(axs,crit):
    P=[];L=[];H=[];X["trend"][name]={}
    for pn,f in per:
        S=[r for r in I if f(cand_y[r["rid"]])]; k=sum(yn(r,key) for r in S); p,lo,hi=wilson(k,len(S)); P.append(100*p);L.append(100*(p-lo));H.append(100*(hi-p)); X["trend"][name][pn]=f"{k}/{len(S)}"
    ax.errorbar(range(3),P,yerr=[L,H],fmt="o-",color=S1,ecolor=INK2,elinewidth=0.8,capsize=2,lw=1.8,ms=4,zorder=3)
    for i,p in enumerate(P): ax.text(i,p+H[i]+2.5,f"{p:.0f}",ha="center",fontsize=6.5,color=INK)
    ax.set_xticks(range(3)); ax.set_xticklabels(["23–24","25","26"],fontsize=6.5); ax.set_title(name,fontsize=6.8,color=INK); ax.yaxis.grid(True,color=GRID,zorder=0); ax.set_ylim(0,85); ax.set_xlim(-0.4,2.4)
axs[0].set_ylabel("Studies meeting criterion (%)")
fig.tight_layout(w_pad=0.4); fig.savefig(f"{OUT}/fig_trend.pdf"); fig.savefig(f"{OUT}/fig_trend.png",dpi=300); plt.close(fig)

# ---- Fig heatmap maturity x tier
mats=["lab","prototype","pilot","deployed"]; tiers=["E0","E1","E2","E3"]
M=np.array([[sum(1 for r in I if r["maturity"].strip()==m and r["evidence_tier"]==t) for t in tiers] for m in mats]); X["maturity_tier"]=M.tolist()
fig,ax=plt.subplots(figsize=(3.3,2.3))
from matplotlib.colors import LinearSegmentedColormap, LogNorm
cm=LinearSegmentedColormap.from_list("b",["#F3F7FD","#86B6EF","#256ABF","#104281"])
ax.imshow(np.where(M>0,M,0.5),cmap=cm,norm=LogNorm(vmin=0.5,vmax=M.max()),aspect="auto")
for i in range(4):
    for j in range(4): ax.text(j,i,str(M[i,j]),ha="center",va="center",fontsize=8,color="white" if M[i,j]>=10 else INK)
ax.set_xticks(range(4)); ax.set_xticklabels(["E0\ndemo","E1\nabsolute","E2\ncomparison","E3\ninferential"],fontsize=6.8); ax.set_yticks(range(4)); ax.set_yticklabels(["Lab","Prototype","Pilot","Deployed"])
for s in ax.spines.values(): s.set_visible(False)
ax.set_xticks(np.arange(-.5,4,1),minor=True); ax.set_yticks(np.arange(-.5,4,1),minor=True); ax.grid(which="minor",color="white",linewidth=2); ax.tick_params(which="both",length=0)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_maturity.pdf"); fig.savefig(f"{OUT}/fig_maturity.png",dpi=300); plt.close(fig)

# ---- Fig kappa dot plot
K=[("Screening: proceed to full text",0.91),("Screening: include/unsure/exclude",0.85),("Screening: exclusion code",0.82),("Full text: eligibility",0.75),("Evidence tier",1.00),("Inferential statistics",1.00),("Ablation",1.00),("Single-agent baseline",0.74),("Matched budget",0.72),("Human role",0.67),("Maturity",0.67),("Repeated runs",0.64),("Scope, medium",0.58),("Scope, strict",0.42),("Control-flow set (exact)",0.41)]
K=sorted(K,key=lambda t:t[1])
fig,ax=plt.subplots(figsize=(6.8,3.0))
for lo,hi,lab,c in [(0.21,0.40,"fair","#F7F7F5"),(0.41,0.60,"moderate","#EFEEEA"),(0.61,0.80,"substantial","#E5E4DE"),(0.81,1.0,"almost perfect","#DAD9D1")]:
    ax.axvspan(lo-0.005,hi+0.005,color=c,zorder=0); ax.text((lo+hi)/2,len(K)-0.2,lab,ha="center",va="bottom",fontsize=6.5,color=INK2)
ax.hlines(range(len(K)),0.2,[k for _,k in K],color=S1,lw=1.2,zorder=2); ax.plot([k for _,k in K],range(len(K)),"o",color=S1,ms=6,zorder=3)
for i,(_,k) in enumerate(K): ax.text(k+0.015 if k<0.97 else k-0.02,i+(0 if k<0.97 else 0.0),f"{k:.2f}",va="center",ha="left" if k<0.97 else "right",fontsize=7,color=INK,bbox=dict(fc="white",ec="none",pad=0.6) if k>=0.97 else None)
ax.set_yticks(range(len(K))); ax.set_yticklabels([n for n,_ in K],fontsize=7); ax.set_xlim(0.2,1.03); ax.set_ylim(-0.6,len(K)+0.5); ax.set_xlabel("Cohen's kappa, first pass against blind re-run"); ax.tick_params(axis="y",length=0)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_kappa.pdf"); fig.savefig(f"{OUT}/fig_kappa.png",dpi=300); plt.close(fig)

# ---- Fig forest: sensitivity
names=["Single-agent baseline","Ablation of an agent or mechanism","Repeated runs with variance","Matched-budget single-agent baseline","Inferential statistics"]
sets=[("All (n=373)","ladder",INK),("Core (n=310)","sensitivity_strict_core",S1),("Strict scope (n=148)","sensitivity_strict_scope",S2),("Journal/conf. (n=89)","sensitivity_journal_only","#1baf7a")]
fig,ax=plt.subplots(figsize=(6.8,2.7)); mk=["D","o","s","^"]
for gi,nm in enumerate(names[::-1]):
    for si,(lab,key,col) in enumerate(sets):
        v=R[key][nm]; y=gi+0.27-si*0.18
        ax.errorbar(100*v["p"],y,xerr=[[100*(v["p"]-v["lo"])],[100*(v["hi"]-v["p"])]],fmt=mk[si],color=col,ecolor=col,elinewidth=1,capsize=2,ms=4,label=lab if gi==0 else None,zorder=3)
ax.set_yticks(range(5)); ax.set_yticklabels([n.replace(" of an agent or mechanism","").replace(" single-agent","") for n in names[::-1]],fontsize=7.5); ax.set_xlabel("Studies meeting criterion (%), 95% Wilson interval"); ax.xaxis.grid(True,color=GRID,zorder=0); ax.tick_params(axis="y",length=0); ax.set_xlim(0,70)
ax.legend(frameon=False,fontsize=6.8,loc="lower right")
fig.tight_layout(); fig.savefig(f"{OUT}/fig_sens.pdf"); fig.savefig(f"{OUT}/fig_sens.png",dpi=300); plt.close(fig)
json.dump(X,open(f"{OUT}/results_figs2.json","w"),indent=1,default=str); print(json.dumps(X,default=str)[:1800])
