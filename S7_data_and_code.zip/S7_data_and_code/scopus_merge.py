"""De-duplicate the Scopus export against arXiv + OpenAlex; fill abstracts via OpenAlex by DOI. Key from env."""
import csv,json,re,os,time,urllib.request,urllib.parse,collections
KEY=os.environ['OPENALEX_KEY']
norm=lambda s: re.sub(r'[^a-z0-9]','',(s or '').lower())[:120]
ax=json.load(open('arxiv_records.json')); oa_all=json.load(open('openalex_records.json')); oa=json.load(open('openalex_dedup.json'))
known_t={norm(r['title']):('arXiv',r['rid']) for r in ax}
known_t.update({norm(r['title']):('OpenAlex',r['rid']) for r in oa})
known_d={(r.get('doi') or '').lower():('arXiv',r['rid']) for r in ax if r.get('doi')}
known_d.update({r['doi'].lower():('OpenAlex',r['rid']) for r in oa if r['doi']})
sc=list(csv.DictReader(open('scopus_in/scopus_export_2026-11-09.csv',encoding='utf-8-sig')))
log=collections.Counter(); new=[]; seen=set()
for i,x in enumerate(sc,1):
    d=(x['DOI'] or '').lower().strip(); t=norm(x['Title'])
    if d and d in known_d: log['dup_doi']+=1; continue
    if t in known_t: log['dup_title']+=1; continue
    if t in seen: log['dup_within_scopus']+=1; continue
    seen.add(t)
    new.append({'rid':f'S{i:04d}','source':'Scopus','eid':x['EID'],'doi':d,'title':x['Title'],'year':x['Year'],'venue':x['Source title'],'doctype':x['Document Type'],'authors':x['Authors'],'abstract':''})
# fill abstracts
def get(params):
    params['api_key']=KEY; url='https://api.openalex.org/works?'+urllib.parse.urlencode(params)
    for k in range(5):
        try: return json.load(urllib.request.urlopen(url,timeout=60))
        except Exception: time.sleep(5*(k+1))
    return {'results':[]}
dois=[r['doi'] for r in new if r['doi']]
absd={}
for j in range(0,len(dois),50):
    chunk=dois[j:j+50]
    res=get({'filter':'doi:'+'|'.join(chunk),'per-page':50,'select':'doi,abstract_inverted_index'})
    for w in res['results']:
        inv=w.get('abstract_inverted_index') or {}
        if inv: absd[(w.get('doi') or '').replace('https://doi.org/','').lower()]=' '.join(t for _,t in sorted((p,t) for t,ps in inv.items() for p in ps))
    time.sleep(0.2)
for r in new: r['abstract']=absd.get(r['doi'],'')
log['unique_new']=len(new); log['new_with_abstract']=sum(1 for r in new if r['abstract']); log['new_without_doi']=sum(1 for r in new if not r['doi'])
json.dump(new,open('scopus_dedup.json','w')); json.dump(dict(log),open('scopus_dedup_log.json','w'),indent=1)
print(dict(log))
