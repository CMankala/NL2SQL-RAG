"""Paper 1 (ESWA) analyses: all numbers in the manuscript come from this script.
Input: fulltext/coded_all_final.csv, screen/*.csv, direction/*.csv (if present).
Output: analysis/results.json, analysis/*.tex tables, analysis/fig_*.pdf"""
import csv, json, re, collections, math, os
from scipy.stats import fisher_exact, chi2_contingency
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

B = "/home/claude/p1s"; OUT = f"{B}/analysis"
rows = list(csv.DictReader(open(f"{B}/fulltext/coded_all_final.csv")))
I = [r for r in rows if r["ft_decision"] == "I"]
cand = {r["rid"]: r for r in csv.DictReader(open(f"{B}/screen/fulltext_candidates_all.csv"))}
N = len(I)
R = {"n_included": N}

def wilson(k, n, z=1.96):
    if n == 0: return (float("nan"),) * 3
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, c - h, c + h

def yn(r, k): return r[k].strip().upper().startswith("Y")
def stated(v): return bool(v.strip()) and not v.strip().lower().startswith(("not stated", "none", "n/a", "no "))
def reported_num(v): return stated(v) and bool(re.search(r"\d", v))

# derived fields
for r in I:
    r["stream"] = "arXiv" if r["rid"].startswith("A") else "Journal/conference"
    y = str(cand[r["rid"]]["year"])[:4]; r["year"] = y
    r["code_yes"] = r["code_released"].strip().lower().startswith("yes") or "github" in r["code_released"].lower()
    r["seed_temp"] = reported_num(r["temperature_seed"])
    r["cost_rep"] = reported_num(r["cost_latency"])
    L = r["llms"].lower()
    r["prop"] = bool(re.search(r"gpt|claude|gemini|\bo[134](-mini|-pro)?\b|ernie|qwen-max|qwen-plus|grok|doubao|kimi|hunyuan|spark", L))
    r["open"] = bool(re.search(r"llama|qwen|mistral|mixtral|deepseek|glm|gemma|phi|vicuna|falcon|yi-|internlm|baichuan|olmo", L))
    T = (r["tools_grounding"] + " " + r["validation"]).lower()
    r["t_rag"] = bool(re.search(r"rag|retriev|knowledge graph|vector", T))
    r["t_sim"] = bool(re.search(r"simulat|digital twin|sumo|gazebo|isaac|carla|energyplus|fem|cfd|spice", T))
    r["t_solver"] = bool(re.search(r"solver|milp|gurobi|cplex|optimi[sz]|linear program|ortools|or-tools", T))
    r["t_exec"] = bool(re.search(r"code exec|execut|compil|python|interpreter|verilog sim|testbench|lint", T))
    r["t_phys"] = bool(re.search(r"robot|hardware|plc|ros|drone|uav|vehicle|machine tool|cnc|sensor", T))
    r["cf"] = sorted(set(re.findall(r"C[1-8]", r["control_flow"])))
    r["E"] = r["evidence_tier"].strip()

def prop(key, sub=None, fn=None):
    S = I if sub is None else sub
    k = sum(1 for r in S if (fn(r) if fn else yn(r, key)))
    p, lo, hi = wilson(k, len(S)); return {"k": k, "n": len(S), "p": p, "lo": lo, "hi": hi}

ladder = [
    ("Single-agent baseline", lambda r: yn(r, "baseline_single")),
    ("Ablation of an agent or mechanism", lambda r: yn(r, "ablation_yn")),
    ("Repeated runs with variance", lambda r: yn(r, "repeated_runs_yn")),
    ("Matched-budget single-agent baseline", lambda r: yn(r, "matched_budget")),
    ("Inferential statistics", lambda r: yn(r, "stats_test")),
    ("Cost or latency reported", lambda r: r["cost_rep"]),
    ("Temperature or seed reported", lambda r: r["seed_temp"]),
    ("Code released", lambda r: r["code_yes"]),
]
R["ladder"] = {name: prop(None, fn=f) for name, f in ladder}
R["evidence_tier"] = dict(collections.Counter(r["E"] for r in I))
R["maturity"] = dict(collections.Counter(r["maturity"].strip() for r in I))
R["human_role"] = dict(collections.Counter(r["human_role_cat"].strip() for r in I))
R["scope_medium"] = dict(collections.Counter(r["scope_medium"].strip() for r in I))
R["scope_strict"] = dict(collections.Counter(r["scope_strict"].strip() for r in I))
R["type"] = dict(collections.Counter(r["type"].strip() for r in I))
R["domain"] = dict(collections.Counter(r["domain_class"].strip() for r in I).most_common())
R["year"] = dict(sorted(collections.Counter(r["year"] for r in I).items()))
R["year_stream"] = {s: dict(sorted(collections.Counter(r["year"] for r in I if r["stream"] == s).items())) for s in ["arXiv", "Journal/conference"]}
R["stream"] = dict(collections.Counter(r["stream"] for r in I))
R["control_flow"] = dict(sorted(collections.Counter(c for r in I for c in r["cf"]).items()))
R["cf_count"] = dict(collections.Counter(len(r["cf"]) for r in I))
R["llm"] = {"proprietary": prop(None, fn=lambda r: r["prop"]), "open_weight": prop(None, fn=lambda r: r["open"]),
            "both": prop(None, fn=lambda r: r["prop"] and r["open"]), "not_stated": prop(None, fn=lambda r: not stated(r["llms"]))}
R["tools"] = {k: prop(None, fn=lambda r, k=k: r[k]) for k in ["t_rag", "t_sim", "t_solver", "t_exec", "t_phys"]}

# stream comparison
def fisher(fn, a, b):
    A = [r for r in I if a(r)]; Bb = [r for r in I if b(r)]
    t = [[sum(fn(r) for r in A), len(A) - sum(fn(r) for r in A)], [sum(fn(r) for r in Bb), len(Bb) - sum(fn(r) for r in Bb)]]
    o, p = fisher_exact(t); return {"a": t[0], "b": t[1], "odds": o, "p": p}
isA = lambda r: r["stream"] == "arXiv"; isJ = lambda r: r["stream"] != "arXiv"
R["stream_test"] = {name: fisher(f, isA, isJ) for name, f in ladder[:5]}
R["stream_test"]["E3"] = fisher(lambda r: r["E"] == "E3", isA, isJ)
R["stream_test"]["lab_only"] = fisher(lambda r: r["maturity"].strip() == "lab", isA, isJ)

# year trend (<=2025 vs 2026)
early = lambda r: r["year"] <= "2025"; late = lambda r: r["year"] == "2026"
R["year_test"] = {name: fisher(f, early, late) for name, f in ladder[:5]}

# domain x evidence
doms = [d for d, _ in collections.Counter(r["domain_class"].strip() for r in I).most_common()]
R["domain_evidence"] = {d: {"n": sum(1 for r in I if r["domain_class"].strip() == d),
                            **{e: sum(1 for r in I if r["domain_class"].strip() == d and r["E"] == e) for e in ["E0", "E1", "E2", "E3"]},
                            "matched": sum(1 for r in I if r["domain_class"].strip() == d and yn(r, "matched_budget")),
                            "lab": sum(1 for r in I if r["domain_class"].strip() == d and r["maturity"].strip() == "lab")} for d in doms}
ct = [[R["domain_evidence"][d][e] for e in ["E0", "E1", "E2", "E3"]] for d in doms]
chi, p, dof, _ = chi2_contingency(ct); R["domain_evidence_chi2"] = {"chi2": chi, "p": p, "dof": dof, "note": "sparse cells; descriptive only"}

# control flow x evidence
R["cf_evidence"] = {c: {"n": sum(1 for r in I if c in r["cf"]), "E3": sum(1 for r in I if c in r["cf"] and r["E"] == "E3"),
                        "matched": sum(1 for r in I if c in r["cf"] and yn(r, "matched_budget")),
                        "strict_Y": sum(1 for r in I if c in r["cf"] and r["scope_strict"].strip() == "Y")} for c in [f"C{i}" for i in range(1, 9)]}

# maturity x evidence
R["deployed_pilot"] = [{"rid": r["rid"], "cite": r["short_cite"], "maturity": r["maturity"], "domain": r["domain_class"], "E": r["E"]} for r in I if r["maturity"].strip() in ("pilot", "deployed")]

# sensitivity: screening decision of included studies; retrieval
scr = {r["rid"]: r for r in csv.DictReader(open(f"{B}/screen/screen_merged_all.csv"))}
R["included_by_screen_decision"] = dict(collections.Counter(scr[r["rid"]]["decision"] for r in I))
# sensitivity: excluding studies included only via rule (b) or adjudication-confirmed borderline
adj = {r["rid"] for r in csv.DictReader(open(f"{B}/fulltext/ADJUDICATION_LOG.csv"))}
S2 = [r for r in I if scr[r["rid"]]["decision"] == "I" and r["rid"] not in adj]
R["sensitivity_strict_core"] = {"n": len(S2), **{name: prop(None, sub=S2, fn=f) for name, f in ladder[:5]}}
S3 = [r for r in I if r["scope_strict"].strip() == "Y"]
R["sensitivity_strict_scope"] = {"n": len(S3), **{name: prop(None, sub=S3, fn=f) for name, f in ladder[:5]}}
S4 = [r for r in I if r["stream"] != "arXiv"]
R["sensitivity_journal_only"] = {"n": len(S4), **{name: prop(None, sub=S4, fn=f) for name, f in ladder[:5]}}

# not retrieved: screening-domain keywords (abstract-level map)
nr = [c for c in cand.values() if c["source"] != "arXiv" and not os.path.exists(f"{B}/fulltext/txt/{c['rid']}.txt")]
def dmap(s):
    s = s.lower()
    for k, v in [("eda|chip|rtl|hardware|circuit|verilog", "EDA-hardware"), ("automotive|vehic|driving|traffic|transport|railway|autonomous driv", "automotive-transport"),
                 ("construction|building energy|building automation|smart building|\\bbim\\b|civil eng|hvac|structural", "building-construction"), ("manufact|factory|production line|shop floor|machining", "manufacturing"),
                 ("telecom|network|wireless|5g|6g|ran", "telecom-networks"), ("chem|material", "chemical-materials"),
                 ("uav|drone|aero|aircraft|space", "aerospace-UAV"), ("mechan|cad|design", "mechanical-design"),
                 ("power|energy|grid|electric", "power-energy"), ("supply|logist|warehouse", "supply-chain-logistics"),
                 ("robot", "robotics-field-industrial"), ("process|plc|control", "process-automation"),
                 ("maritime|ship|mining|water|oil|gas", "maritime-mining-water"), ("secur|cyber", "industrial-cybersecurity")]:
        if re.search(k, s): return v
    return "other/unclear"
R["not_retrieved"] = {"n": len(nr), "screen_I": sum(1 for c in nr if c["decision"] == "I"), "screen_U": sum(1 for c in nr if c["decision"] == "U"),
                      "no_abstract": sum(1 for c in nr if c["has_abs"] in ("False", "")),
                      "domain": dict(collections.Counter(dmap(c["domain"] + " " + c["title"]) for c in nr).most_common())}
R["retrieved_included_domain"] = R["domain"]

# direction of single-vs-MAS comparisons
dfiles = [f"{B}/direction/dir_D1.csv", f"{B}/direction/dir_D2.csv"]
if all(os.path.exists(f) for f in dfiles):
    D = {r["rid"]: r for f in dfiles for r in csv.DictReader(open(f))}
    Ii = {r["rid"]: r for r in I}
    for sub, name in [(lambda r: True, "all"), (lambda r: yn(r, "matched_budget"), "matched"), (lambda r: not yn(r, "matched_budget"), "unmatched")]:
        ids = [k for k in D if k in Ii and sub(Ii[k])]
        R[f"direction_{name}"] = {"n": len(ids), **dict(collections.Counter(D[k]["direction"].strip() for k in ids))}
    ids = [k for k in D if k in Ii]
    R["direction_cost"] = {"cost_reported": sum(D[k]["cost_reported"].strip() == "Y" for k in ids), "mas_costlier": sum(D[k]["mas_costlier"].strip() == "Y" for k in ids),
                           "mas_costlier_unknown": sum(D[k]["mas_costlier"].strip().lower().startswith("unk") for k in ids), "n": len(ids)}

json.dump(R, open(f"{OUT}/results.json", "w"), indent=1, default=float)

# ---------------- figures ----------------
INK, INK2, GRID = "#0B0B0B", "#52514E", "#E1E0D9"
BLUE = ["#86B6EF", "#5598E7", "#256ABF", "#104281"]
S1, S2c = "#2a78d6", "#eb6834"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False})

# Fig: evidence ladder with Wilson CIs
fig, ax = plt.subplots(figsize=(6.8, 2.9))
names = [n for n, _ in ladder][::-1]; vals = [R["ladder"][n] for n in names]
y = range(len(names))
ax.barh(y, [100 * v["p"] for v in vals], color=S1, height=0.55, zorder=2)
ax.errorbar([100 * v["p"] for v in vals], y, xerr=[[100 * (v["p"] - v["lo"]) for v in vals], [100 * (v["hi"] - v["p"]) for v in vals]],
            fmt="none", ecolor=INK, elinewidth=0.9, capsize=2.5, zorder=3)
for i, v in enumerate(vals):
    ax.text(100 * v["hi"] + 1.5, i, f"{v['k']}/{v['n']} ({100*v['p']:.1f}%)", va="center", fontsize=7.5, color=INK)
ax.set_yticks(list(y)); ax.set_yticklabels(names); ax.set_xlim(0, 75); ax.set_xlabel("Share of included studies (%), 95% Wilson interval")
ax.xaxis.grid(True, color=GRID, zorder=0); ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_ladder.pdf"); fig.savefig(f"{OUT}/fig_ladder.png", dpi=300); plt.close(fig)

# Fig: studies per year by stream
yrs = ["2023", "2024", "2025", "2026"]
a = [R["year_stream"]["arXiv"].get(y_, 0) for y_ in yrs]; j = [R["year_stream"]["Journal/conference"].get(y_, 0) for y_ in yrs]
fig, ax = plt.subplots(figsize=(3.3, 2.4))
ax.bar(yrs, a, color=S1, width=0.6, label="arXiv", zorder=2, edgecolor="white", linewidth=1)
ax.bar(yrs, j, bottom=a, color=S2c, width=0.6, label="Journal/conference", zorder=2, edgecolor="white", linewidth=1)
for i, (p_, q_) in enumerate(zip(a, j)): ax.text(i, p_ + q_ + 4, str(p_ + q_), ha="center", fontsize=7.5, color=INK)
ax.set_ylabel("Included studies"); ax.yaxis.grid(True, color=GRID, zorder=0); ax.legend(frameon=False, fontsize=7)
ax.text(3, -32, "to 7 Nov", ha="center", fontsize=6.5, color=INK2)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_years.pdf"); fig.savefig(f"{OUT}/fig_years.png", dpi=300); plt.close(fig)

# Fig: domain x evidence tier (stacked, sorted by n)
fig, ax = plt.subplots(figsize=(6.8, 3.6))
left = [0] * len(doms)
labels = {"E0": "E0 demonstration", "E1": "E1 absolute only", "E2": "E2 comparison, no inference", "E3": "E3 matched/inferential"}
yy = list(range(len(doms)))[::-1]
for e, col in zip(["E0", "E1", "E2", "E3"], BLUE):
    v = [R["domain_evidence"][d][e] for d in doms]
    ax.barh(yy, v, left=left, color=col, height=0.62, label=labels[e], edgecolor="white", linewidth=1, zorder=2)
    left = [l + x for l, x in zip(left, v)]
for i, d in enumerate(doms): ax.text(left[i] + 0.6, yy[i], str(left[i]), va="center", fontsize=7, color=INK)
ax.set_yticks(yy); ax.set_yticklabels(doms); ax.set_xlabel("Included studies"); ax.xaxis.grid(True, color=GRID, zorder=0)
ax.legend(frameon=False, fontsize=7, loc="lower right"); ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_domains.pdf"); fig.savefig(f"{OUT}/fig_domains.png", dpi=300); plt.close(fig)

# Fig: control-flow patterns
cfn = {"C1": "C1 fixed pipeline", "C2": "C2 router/supervisor", "C3": "C3 verifier/repair loop", "C4": "C4 negotiation/market",
       "C5": "C5 fan-out + arbiter", "C6": "C6 LLM in classical MAS", "C7": "C7 LLM to solver/formal model", "C8": "C8 debate/critique"}
fig, ax = plt.subplots(figsize=(3.4, 2.7))
keys = sorted(cfn, key=lambda c: R["control_flow"].get(c, 0))
ax.barh([cfn[k] for k in keys], [R["control_flow"].get(k, 0) for k in keys], color=S1, height=0.55, zorder=2)
for i, k in enumerate(keys): ax.text(R["control_flow"].get(k, 0) + 2, i, str(R["control_flow"].get(k, 0)), va="center", fontsize=7, color=INK)
ax.set_xlabel("Studies (a study may use several)"); ax.xaxis.grid(True, color=GRID, zorder=0); ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_controlflow.pdf"); fig.savefig(f"{OUT}/fig_controlflow.png", dpi=300); plt.close(fig)

# Fig: direction of comparisons (if available)
if "direction_all" in R:
    cats = ["MAS_better", "mixed", "tie", "single_better", "unclear"]; lab = ["MAS better", "Mixed", "Tie", "Single better", "Unclear"]
    cols = ["#256ABF", "#86B6EF", "#C3C2B7", "#eb6834", "#E1E0D9"]
    fig, ax = plt.subplots(figsize=(6.8, 1.6))
    for row, name in enumerate(["unmatched", "matched"]):
        d = R[f"direction_{name}"]; l = 0
        for c, lb, col in zip(cats, lab, cols):
            v = d.get(c, 0)
            if v: ax.barh(row, v / d["n"] * 100, left=l, color=col, edgecolor="white", linewidth=1, height=0.55, label=lb if row == 0 else None)
            if v / d["n"] > 0.06: ax.text(l + v / d["n"] * 50, row, str(v), ha="center", va="center", fontsize=7, color="white" if c == "MAS_better" else INK)
            l += v / d["n"] * 100
    ax.set_yticks([0, 1]); ax.set_yticklabels([f"Unmatched budget (n={R['direction_unmatched']['n']})", f"Matched budget (n={R['direction_matched']['n']})"])
    ax.set_xlim(0, 100); ax.set_xlabel("Share of single-agent comparisons (%)"); ax.tick_params(axis="y", length=0)
    ax.legend(frameon=False, fontsize=7, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.45))
    fig.tight_layout(); fig.savefig(f"{OUT}/fig_direction.pdf"); fig.savefig(f"{OUT}/fig_direction.png", dpi=300); plt.close(fig)
print(json.dumps({k: R[k] for k in ["n_included", "evidence_tier", "stream", "year", "control_flow", "llm", "tools", "included_by_screen_decision", "not_retrieved"]}, indent=0, default=float)[:3000])
for k in ["stream_test", "year_test"]:
    print(k, {n: (v["a"], v["b"], round(v["p"], 4)) for n, v in R[k].items()})
for k in ["sensitivity_strict_core", "sensitivity_strict_scope", "sensitivity_journal_only"]:
    print(k, R[k]["n"], {n: f"{v['k']}/{v['n']} {100*v['p']:.1f}" for n, v in R[k].items() if n != "n"})
print({n: f"{v['k']} {100*v['p']:.1f} [{100*v['lo']:.1f},{100*v['hi']:.1f}]" for n, v in R["ladder"].items()})
