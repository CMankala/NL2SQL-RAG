"""Scripted arXiv search for the engineering LLM multi-agent review. Logs query, hit count, retrieval time."""
import urllib.request, urllib.parse, re, time, json, datetime, sys
LLM='(abs:"language model" OR abs:"language models" OR abs:LLM OR abs:LLMs OR abs:GPT OR abs:ChatGPT OR abs:"foundation model" OR abs:"generative AI")'
MAS='(abs:"multi-agent" OR abs:multiagent OR abs:"multi agent" OR abs:"multiple agents" OR abs:"agent collaboration" OR abs:"collaborating agents" OR abs:"agent team" OR abs:"multi-robot" OR abs:multirobot OR abs:"multi-UAV")'
DOM=('(abs:manufacturing OR abs:industrial OR abs:industry OR abs:factory OR abs:construction OR abs:"civil engineering" OR abs:structural '
 'OR abs:"power system" OR abs:"power systems" OR abs:"power grid" OR abs:"smart grid" OR abs:"energy system" OR abs:"energy management" OR abs:"electric vehicle" '
 'OR abs:chemical OR abs:"process engineering" OR abs:"process control" OR abs:mechanical OR abs:aerospace OR abs:aircraft OR abs:automotive OR abs:vehicle '
 'OR abs:HVAC OR abs:"building energy" OR abs:"building automation" OR abs:CAD OR abs:"engineering design" OR abs:"digital twin" OR abs:"supply chain" '
 'OR abs:logistics OR abs:"control system" OR abs:PLC OR abs:robotics OR abs:mining OR abs:"oil and gas" OR abs:maritime OR abs:transportation OR abs:"water distribution")')
D='submittedDate:[202301010000 TO 202611072359]'
Q=f'{LLM} AND {MAS} AND {DOM} AND {D}'
log={'source':'arXiv API','query':Q,'run_utc':datetime.datetime.utcnow().isoformat()+'Z'}
recs=[];start=0;total=None
while True:
    url='https://export.arxiv.org/api/query?'+urllib.parse.urlencode({'search_query':Q,'start':start,'max_results':1000,'sortBy':'submittedDate','sortOrder':'ascending'})
    for attempt in range(5):
        try: x=urllib.request.urlopen(url,timeout=120).read().decode(); break
        except Exception as e: time.sleep(10)
    if total is None: total=int(re.search(r'<opensearch:totalResults[^>]*>(\d+)',x).group(1)); print('total',total)
    ents=re.findall(r'<entry>(.*?)</entry>',x,re.S)
    if not ents: break
    for e in ents:
        g=lambda t:(re.search(rf'<{t}[^>]*>(.*?)</{t}>',e,re.S) or [None,''])[1]
        recs.append({'id':g('id').strip(),'title':' '.join(g('title').split()),'abstract':' '.join(g('summary').split()),
          'published':g('published')[:10],'authors':[' '.join(a.split()) for a in re.findall(r'<name>(.*?)</name>',e)],
          'doi':(re.search(r'<arxiv:doi[^>]*>(.*?)</arxiv:doi>',e) or [None,''])[1],
          'journal_ref':' '.join((re.search(r'<arxiv:journal_ref[^>]*>(.*?)</arxiv:journal_ref>',e,re.S) or [None,''])[1].split())})
    start+=len(ents); print(start); time.sleep(3.5)
    if start>=total: break
log['hits']=total; log['retrieved']=len(recs)
json.dump(recs,open('arxiv_records.json','w')); json.dump(log,open('arxiv_log.json','w'),indent=1)
print(log['hits'],log['retrieved'])
