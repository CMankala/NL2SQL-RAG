"""Logged OpenAlex search (Paper 1). Key read from env OPENALEX_KEY (never written to disk)."""
import os,json,time,urllib.request,urllib.parse,datetime,sys
KEY=os.environ['OPENALEX_KEY']
LLM='("large language model" OR "large language models" OR LLM OR LLMs OR GPT OR ChatGPT OR "foundation model" OR "generative AI")'
MAS='("multi-agent" OR multiagent OR "multi agent" OR "multiple agents" OR "agent collaboration" OR "collaborating agents" OR "agent team" OR "multi-robot" OR multirobot OR "multi-UAV" OR "agentic workflow")'
DOM='(manufacturing OR industrial OR industry OR factory OR construction OR "civil engineering" OR structural OR "power system" OR "power grid" OR "smart grid" OR "energy system" OR "energy management" OR "electric vehicle" OR chemical OR "process engineering" OR "process control" OR mechanical OR aerospace OR aircraft OR automotive OR vehicle OR HVAC OR "building energy" OR "building automation" OR CAD OR "engineering design" OR "digital twin" OR "supply chain" OR logistics OR "control system" OR PLC OR robotics OR mining OR "oil and gas" OR maritime OR transportation OR "water distribution")'
Q=f'{LLM} AND {MAS} AND {DOM}'
FILT=f'title_and_abstract.search:{Q},publication_year:2023-2026,type:article|conference-paper|preprint,language:en'
def get(params):
    params['api_key']=KEY
    url='https://api.openalex.org/works?'+urllib.parse.urlencode(params)
    for i in range(5):
        try: return json.load(urllib.request.urlopen(url,timeout=60))
        except Exception as e: print('retry',e,file=sys.stderr); time.sleep(5*(i+1))
    raise SystemExit('failed')
if __name__=='__main__':
    countonly=len(sys.argv)>1 and sys.argv[1]=='count'
    first=get({'filter':FILT,'per-page':1})
    n=first['meta']['count']; print('hits',n)
    if countonly: raise SystemExit
    out=[];cur='*'
    sel='id,doi,title,display_name,publication_year,publication_date,type,primary_location,authorships,abstract_inverted_index,language'
    while cur:
        d=get({'filter':FILT,'per-page':200,'cursor':cur,'select':sel})
        for w in d['results']:
            inv=w.get('abstract_inverted_index') or {}
            pos=sorted((p,t) for t,ps in inv.items() for p in ps)
            src=((w.get('primary_location') or {}).get('source') or {})
            out.append({'oaid':w['id'],'doi':(w.get('doi') or '').replace('https://doi.org/',''),'title':w.get('display_name') or '',
              'abstract':' '.join(t for _,t in pos),'year':w.get('publication_year'),'date':w.get('publication_date'),
              'venue':src.get('display_name') or '','publisher':src.get('host_organization_name') or '','source_type':src.get('type') or '',
              'authors':[a['author']['display_name'] for a in w.get('authorships',[])]})
        cur=d['meta'].get('next_cursor'); time.sleep(0.2)
        if not d['results']: break
    for i,r in enumerate(out,1): r['rid']=f'O{i:04d}'
    D='/home/claude/p1s/search'
    json.dump(out,open(f'{D}/openalex_records.json','w'))
    json.dump({'source':'OpenAlex API','query':Q,'filter':FILT.replace(Q,'<Q>'),'run_utc':datetime.datetime.utcnow().isoformat()+'Z','hits':n,'retrieved':len(out)},open(f'{D}/openalex_log.json','w'),indent=1)
    print('retrieved',len(out))
