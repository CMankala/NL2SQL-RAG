# benchmark

The evaluation set of the paper (Sec. IV-A) is derived from BIRD and Spider, which are
not redistributed here. Download them from their original sources:

- BIRD: https://bird-bench.github.io
- Spider: https://yale-lily.github.io/spider

This release does not yet include the schema-scaling and data-synthesis scripts or the
1,500-question set with gold SQL. Place them in this folder when they are published:

| Item | Paper reference |
|---|---|
| Schema extraction (143 schemas) | Sec. IV-A, step 1 |
| Schema scaling to 10, 50 and 120 tables | Sec. IV-A, step 2 |
| Synthetic data generation | Sec. IV-A, step 3 |
| Question set with gold SQL | Sec. IV-A, step 4 |
