import json
import sqlite3
import numpy as np
import pytest
from demo import CATALOG, DDL, QUESTIONS, call
from nl2sql_rag.compiler.glsl import GLSLCompiler, ValidationError, to_sql
from nl2sql_rag.eval.metrics import (execution_match, referenced_columns, schema_element_recall,
                                     structural_hallucination_rate, tool_call_columns)
from nl2sql_rag.eval.stats import newcombe_interval, wilson_interval
from nl2sql_rag.gateway.automaton import EMPTY, advance, matches
from nl2sql_rag.gateway.masking import EOS, TokenMask, constrained_decode, masked_distribution
from nl2sql_rag.gateway.schema import compile_schema, compile_tool_call
from nl2sql_rag.gateway.server import ToolServer
from nl2sql_rag.gateway.tools import build_tools
from nl2sql_rag.llm import ScriptedLLM, build_vocabulary
from nl2sql_rag.orchestration.pipeline import Pipeline
from nl2sql_rag.retrieval.css import collective_schema_subsetting
from nl2sql_rag.retrieval.hybrid import HybridIndex

TOOLS = build_tools(CATALOG, list(CATALOG.tables))
VOCAB = build_vocabulary(CATALOG.qualified_columns())


# ------------------------------ gateway ------------------------------
def test_schema_automaton_accepts_and_rejects():
    p = compile_schema({"type": "object", "properties": {
        "c": {"enum": ["a.x", "a.y"]}, "n": {"type": "integer"},
        "v": {"type": "array", "items": {"type": "string", "maxLength": 3}, "maxItems": 2}}})
    assert matches(p, '{"c":"a.x","n":-12,"v":["ab","c"]}')
    assert matches(p, '{"c":"a.y","n":0,"v":[]}')
    assert not matches(p, '{"c":"a.z","n":0,"v":[]}')          # value outside the enum
    assert not matches(p, '{"c":"a.x","n":01,"v":[]}')         # leading zero
    assert not matches(p, '{"c":"a.x","n":1,"v":["abcd"]}')    # maxLength
    assert not matches(p, '{"c":"a.x","n":1,"v":["a","b","c"]}')  # maxItems
    assert not matches(p, '{"n":1,"c":"a.x","v":[]}')          # key order is canonical


def test_mask_blocks_nonexistent_identifier():
    pattern = compile_tool_call(TOOLS)
    prefix = '{"name":"select_rows","arguments":{"columns":["customers.'
    state = advance(pattern, prefix)
    assert advance(state, "name") is not EMPTY
    assert advance(state, "fullname") is EMPTY
    tracker = TokenMask(VOCAB, pattern)
    tracker.consume(prefix)
    mask = tracker.mask()
    logits = np.zeros(len(VOCAB)); logits[VOCAB.index("f")] = 50.0     # the model "wants" customers.f...
    p = masked_distribution(logits, mask, temperature=1.0)
    assert not mask[VOCAB.index("f")] and p[VOCAB.index("f")] == 0.0
    assert abs(p.sum() - 1.0) < 1e-12
    assert not mask[VOCAB.index(EOS)]                                  # output is not complete yet


def test_greedy_tie_break_is_highest_index():
    p = masked_distribution(np.zeros(5), np.array([True, True, False, True, False]), temperature=0.0)
    assert p.argmax() == 3 and p.sum() == 1.0


def test_constrained_decode_follows_valid_candidate():
    question = "Total quantity ordered per product category"
    out = constrained_decode(ScriptedLLM(VOCAB, QUESTIONS[question]), VOCAB, compile_tool_call(TOOLS))
    assert matches(compile_tool_call(TOOLS), out)
    assert json.loads(out)["arguments"]["group_by"] == ["products.category"]
    assert "product_category" not in out


def test_every_decoded_output_is_schema_valid_under_random_logits():
    rng = np.random.default_rng(0)
    pattern = compile_tool_call(TOOLS)
    eos = VOCAB.index(EOS)
    for _ in range(25):
        def noisy(prefix):
            z = rng.normal(size=len(VOCAB)); z[eos] += 2.0 + 0.05 * len(prefix)   # nudge toward stopping
            return z
        out = constrained_decode(noisy, VOCAB, pattern, max_steps=4000)
        cols = tool_call_columns(json.loads(out)["arguments"])
        assert matches(pattern, out)
        assert structural_hallucination_rate([cols], CATALOG) == 0.0


# ------------------------------ compiler ------------------------------
def test_compiler_plans_fk_joins_and_parameterizes():
    ast = GLSLCompiler(CATALOG).compile("select_rows", {
        "columns": ["customers.name", "products.title"],
        "filters": [{"column": "products.price", "op": ">", "value": 100}], "order_by": [], "limit": 5})
    sql, params = to_sql(ast, "%s")
    assert [j.table for j in ast.joins] == ["orders", "order_items", "products"]
    assert params == [100] and "%s" in sql and "100" not in sql


def test_compiler_rejects_unknown_and_unjoinable():
    c = GLSLCompiler(CATALOG)
    with pytest.raises(ValidationError) as e:
        c.compile("select_rows", {"columns": ["customers.fullname"]})
    assert e.value.identifier == "customers.fullname"
    with pytest.raises(ValidationError):                        # warehouses has no FK to customers
        c.compile("select_rows", {"columns": ["customers.name", "warehouses.city"]})


def test_server_json_rpc_roundtrip():
    conn = sqlite3.connect(":memory:"); conn.executescript(DDL)
    server = ToolServer(CATALOG, conn)
    assert {t["name"] for t in server.handle({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})["result"]["tools"]} \
        == {"select_rows", "aggregate"}
    args = json.loads(QUESTIONS["Which customers live in Italy?"][0])["arguments"]
    res = server.handle({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                         "params": {"name": "select_rows", "arguments": args}})["result"]
    assert not res["isError"] and json.loads(res["content"][0]["text"])["rows"] == [["Ada"], ["Linus"]]
    bad = server.handle({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
                         "params": {"name": "select_rows", "arguments": {"columns": ["x.y"]}}})["result"]
    assert bad["isError"]


# ------------------------------ retrieval ------------------------------
def test_css_grounds_and_expands_along_fks():
    index = HybridIndex(CATALOG.chunks())
    g = collective_schema_subsetting("product category", CATALOG, index, theta=0.3, k=5, h=1)
    assert "products.category" in g.element_ids
    assert "order_items" in g.tables and "customers" not in g.tables       # one hop only
    g2 = collective_schema_subsetting("product category", CATALOG, index, theta=0.3, k=5, h=3)
    assert "customers" in g2.tables and "warehouses" not in g2.tables      # unreachable stays out
    blocked = collective_schema_subsetting("product category", CATALOG, index, theta=0.3, k=5,
                                           negative=frozenset({"products.category"}))
    assert "products.category" not in blocked.element_ids


def test_adaptive_alpha_is_bounded():
    index = HybridIndex(CATALOG.chunks(), alpha0=0.75)
    for q in ["customer country", "thing", "quantity of units ordered"]:
        scores, alpha = index.score(q)
        assert 0.0 <= alpha <= 0.75 and scores.shape == (len(index.chunks),)


def test_fk_expansion_bound_from_the_paper():
    """h-hop expansion of two anchors covers every table on a path of length L <= 2h + 1."""
    path = CATALOG.fk_path({"customers"}, "products")           # customers-orders-order_items-products
    assert len(path) == 3
    assert {"orders", "order_items"} <= CATALOG.within_hops(["customers", "products"], 1)


# ------------------------------ pipeline & metrics ------------------------------
def test_pipeline_end_to_end_execution_accuracy():
    conn = sqlite3.connect(":memory:"); conn.executescript(DDL)
    pipe = Pipeline(CATALOG, VOCAB, lambda q, ctx, tools: ScriptedLLM(VOCAB, QUESTIONS[q]),
                    connection=conn, theta=0.30)
    gold = {
        "Which customers live in Italy?": "SELECT name FROM customers WHERE country='Italy'",
        "Total quantity ordered per product category":
            "SELECT p.category, SUM(i.quantity) FROM order_items i JOIN products p USING(product_id) GROUP BY 1",
        "Names of customers and the titles of products they ordered":
            "SELECT c.name, p.title FROM customers c JOIN orders o USING(customer_id) "
            "JOIN order_items i USING(order_id) JOIN products p USING(product_id)",
    }
    for q, sql in gold.items():
        state = pipe.run(q)
        assert state.status == "ok"
        assert execution_match(state.result["rows"], conn.execute(sql).fetchall())


def test_pipeline_reports_no_tool_when_nothing_is_grounded():
    pipe = Pipeline(CATALOG, VOCAB, lambda q, ctx, tools: ScriptedLLM(VOCAB, []), theta=0.99)
    assert pipe.run("zzz qqq").status == "no_tool"


def test_metrics():
    assert schema_element_recall([{"a.x", "a.y"}, {"b.z"}], [{"a.x"}, {"b.z", "b.w"}]) == pytest.approx(2 / 3)
    outs = [{"customers.name"}, {"customers.fullname"}, {"nope.x"}, {"orders.order_id"}]
    assert structural_hallucination_rate(outs, CATALOG) == 0.5
    assert referenced_columns('SELECT "customers"."name" FROM customers c WHERE orders.order_id = 1') \
        == {"customers.name", "orders.order_id"}


def test_intervals_reproduce_the_paper():
    r = lambda t: tuple(round(100 * v, 1) for v in t)
    assert r(wilson_interval(0.914, 1500)) == (89.9, 92.7)
    assert r(wilson_interval(0.682, 1500)) == (65.8, 70.5)
    assert r(wilson_interval(0.491, 1500)) == (46.6, 51.6)
    assert r(newcombe_interval(0.914, 1500, 0.682, 1500)) == (20.4, 25.9)
    assert r(newcombe_interval(0.961, 1500, 0.942, 1500)) == (0.4, 3.5)
    assert r(newcombe_interval(0.914, 1500, 0.749, 1500)) == (13.9, 19.1)
