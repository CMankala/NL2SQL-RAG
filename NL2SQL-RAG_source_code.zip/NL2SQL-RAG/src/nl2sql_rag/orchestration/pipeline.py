"""Multi-turn orchestration: retrieval -> constrained tool call -> compilation.

The control flow is the cyclic graph of the paper (retrieve, generate, validate, and
on a validation failure return to retrieval with negative constraints). It is written
as a plain loop so that the package has no orchestration dependency; each stage is a
separate method and can be registered as a LangGraph node unchanged.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Callable, Sequence
import numpy as np
from ..catalog import Catalog
from ..compiler.glsl import ValidationError
from ..gateway.masking import constrained_decode
from ..gateway.schema import compile_tool_call
from ..gateway.server import ToolServer
from ..retrieval.css import GroundedContext, collective_schema_subsetting, heuristic_virtual_schema
from ..retrieval.hybrid import HybridIndex

# logits_factory(question, context, tools) -> logits_fn(prefix) -> np.ndarray over the vocabulary
LogitsFactory = Callable[[str, GroundedContext, list], Callable[[str], np.ndarray]]


@dataclass
class State:
    """S = <M_hist, I_intent, T_params, E_status>."""
    history: list[dict] = field(default_factory=list)       # M_hist
    intent: str = ""                                        # I_intent
    tool_params: dict | None = None                         # T_params
    status: str = "pending"                                 # E_status: pending | ok | no_tool | failed
    context: GroundedContext | None = None
    result: dict | None = None
    negative: set[str] = field(default_factory=set)


class Pipeline:
    def __init__(self, catalog: Catalog, vocab: Sequence[str], logits_factory: LogitsFactory, *,
                 connection=None, placeholder: str = "?", embedder=None, theta: float = 0.62, k: int = 40,
                 h: int = 1, alpha0: float = 0.75, max_turns: int = 3,
                 virtual_schema_fn=heuristic_virtual_schema):
        self.catalog, self.vocab, self.logits_factory = catalog, list(vocab), logits_factory
        self.index = HybridIndex(catalog.chunks(), embedder=embedder, alpha0=alpha0)
        self.server = ToolServer(catalog, connection, placeholder)
        self.theta, self.k, self.h, self.max_turns = theta, k, h, max_turns
        self.virtual_schema_fn = virtual_schema_fn

    # ---- nodes ----
    def retrieve(self, state: State) -> State:
        state.context = collective_schema_subsetting(
            state.intent, self.catalog, self.index, theta=self.theta, k=self.k, h=self.h,
            virtual_schema_fn=self.virtual_schema_fn, negative=frozenset(state.negative))
        return state

    def generate(self, state: State) -> State:
        tools = self.server.tools(state.context.tables)
        if not tools:                       # nothing grounded: documentation fallback, no SQL
            state.status = "no_tool"
            return state
        logits_fn = self.logits_factory(state.intent, state.context, tools)
        text = constrained_decode(logits_fn, self.vocab, compile_tool_call(tools), temperature=0.0)
        state.tool_params = json.loads(text)
        return state

    def execute(self, state: State) -> State:
        call = state.tool_params
        state.result = self.server.call(call["name"], call["arguments"], state.context.tables)
        state.status = "ok"
        return state

    # ---- graph ----
    def run(self, question: str) -> State:
        state = State(intent=question)
        for turn in range(self.max_turns):
            state = self.generate(self.retrieve(state))
            if state.status == "no_tool":
                break
            try:
                state = self.execute(state)
                state.history.append({"turn": turn, "call": state.tool_params, "status": "ok"})
                return state
            except ValidationError as exc:
                state.history.append({"turn": turn, "call": state.tool_params, "status": "invalid", "error": str(exc)})
                if exc.identifier:
                    state.negative.add(exc.identifier)          # negative constraint for the next pass
        if state.status != "no_tool":
            state.status = "failed"
        return state
