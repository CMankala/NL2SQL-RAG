"""Schema catalog: tables, columns, foreign keys, and the FK graph."""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass, field


@dataclass(frozen=True)
class ForeignKey:
    table: str
    column: str
    ref_table: str
    ref_column: str


@dataclass
class Table:
    name: str
    columns: dict[str, str]                 # column name -> SQL type
    description: str = ""
    column_docs: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class Chunk:
    """One retrievable unit of schema metadata (a table or a column)."""
    id: str            # "table" or "table.column"
    table: str
    text: str


class Catalog:
    def __init__(self, tables: list[Table], fks: list[ForeignKey] = ()):
        self.tables = {t.name: t for t in tables}
        self.fks = list(fks)
        self._adj: dict[str, list[tuple[str, ForeignKey]]] = {t: [] for t in self.tables}
        for fk in self.fks:
            self._adj[fk.table].append((fk.ref_table, fk))
            self._adj[fk.ref_table].append((fk.table, fk))

    # ---- identifiers -------------------------------------------------
    def has_column(self, table: str, column: str) -> bool:
        return table in self.tables and column in self.tables[table].columns

    def qualified_columns(self, tables=None) -> list[str]:
        names = self.tables if tables is None else [t for t in self.tables if t in set(tables)]
        return [f"{t}.{c}" for t in names for c in self.tables[t].columns]

    def chunks(self) -> list[Chunk]:
        out = []
        for t in self.tables.values():
            out.append(Chunk(t.name, t.name, f"table {t.name}: {t.description}"))
            for c, typ in t.columns.items():
                doc = t.column_docs.get(c, "")
                out.append(Chunk(f"{t.name}.{c}", t.name, f"{t.name}.{c} ({typ}) {doc}"))
        return out

    # ---- FK graph ----------------------------------------------------
    def neighbors(self, table: str) -> list[str]:
        return [n for n, _ in self._adj.get(table, [])]

    def within_hops(self, tables, h: int) -> set[str]:
        """Tables reachable from `tables` in at most h FK hops (Alg. 1, Phase 3)."""
        seen = set(tables)
        frontier = set(tables)
        for _ in range(h):
            frontier = {n for t in frontier for n in self.neighbors(t)} - seen
            seen |= frontier
        return seen

    def fk_path(self, sources, target: str):
        """Shortest FK path from any table in `sources` to `target` (list of FK edges
        in traversal order), or None if the target is unreachable."""
        sources = set(sources)
        if target in sources:
            return []
        prev = {s: None for s in sources}
        queue = deque(sources)
        while queue:
            t = queue.popleft()
            for n, fk in self._adj.get(t, []):
                if n in prev:
                    continue
                prev[n] = (t, fk)
                if n == target:
                    path = []
                    while prev[n] is not None:
                        t0, e = prev[n]
                        path.append((t0, n, e))
                        n = t0
                    return path[::-1]
                queue.append(n)
        return None
