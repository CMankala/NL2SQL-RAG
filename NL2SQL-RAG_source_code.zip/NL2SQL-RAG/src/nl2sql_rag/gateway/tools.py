"""Tool catalog: JSON schemas whose enumerations are drawn from the grounded context.

Two tools cover single- and multi-table SELECT with filters, ordering and limits,
and aggregation with GROUP BY. Every identifier-valued parameter is an ``enum`` over
the columns of the tables in G, which is what confines emitted identifiers to the
catalog. A question outside this fragment (set operations, sub-queries, window
functions, HAVING, ...) cannot be expressed.
"""
from __future__ import annotations
from ..catalog import Catalog

OPERATORS = ["=", "!=", "<", "<=", ">", ">=", "like"]
AGGREGATES = ["count", "sum", "avg", "min", "max"]


def build_tools(catalog: Catalog, tables: list[str], *, max_columns: int = 8, max_filters: int = 4) -> list[dict]:
    columns = catalog.qualified_columns(tables)
    if not columns:
        return []
    column = {"enum": columns}
    filters = {
        "type": "array", "minItems": 0, "maxItems": max_filters,
        "items": {"type": "object", "properties": {
            "column": column,
            "op": {"enum": OPERATORS},
            "value": {"anyOf": [{"type": "integer"}, {"type": "string", "maxLength": 64}]},
        }},
    }
    order_by = {
        "type": "array", "minItems": 0, "maxItems": 2,
        "items": {"type": "object", "properties": {"column": column, "direction": {"enum": ["asc", "desc"]}}},
    }
    limit = {"type": "integer"}
    return [
        {
            "name": "select_rows",
            "description": "Return columns of one or more FK-connected tables, optionally filtered and ordered.",
            "inputSchema": {"type": "object", "properties": {
                "columns": {"type": "array", "items": column, "minItems": 1, "maxItems": max_columns},
                "filters": filters, "order_by": order_by, "limit": limit}},
        },
        {
            "name": "aggregate",
            "description": "Aggregate a column, optionally grouped by other columns and filtered.",
            "inputSchema": {"type": "object", "properties": {
                "metrics": {"type": "array", "minItems": 1, "maxItems": 4, "items": {
                    "type": "object", "properties": {"function": {"enum": AGGREGATES}, "column": column}}},
                "group_by": {"type": "array", "items": column, "minItems": 0, "maxItems": 4},
                "filters": filters, "limit": limit}},
        },
    ]
