"""Incremental validity tracker for constrained decoding.

A JSON schema is compiled to a regular expression over characters, and the tracker
advances through it with Brzozowski derivatives. Nodes are hash-consed, so each
(state, character) transition is computed once. This is the "incremental JSON-schema
parser" that produces the binary mask M(x_t) of paper Eq. 5.
"""
from __future__ import annotations


class Node:
    __slots__ = ("kind", "args", "nullable", "_deriv")

    def __repr__(self):
        return f"<{self.kind}>"


_TABLE: dict[tuple, Node] = {}


def _mk(kind: str, *args) -> Node:
    key = (kind,) + args
    n = _TABLE.get(key)
    if n is None:
        n = Node()
        n.kind, n.args, n._deriv = kind, args, {}
        if kind in ("empty", "chars"):
            n.nullable = False
        elif kind == "eps":
            n.nullable = True
        elif kind == "seq":
            n.nullable = args[0].nullable and args[1].nullable
        elif kind == "alt":
            n.nullable = any(a.nullable for a in args[0])
        else:  # rep
            n.nullable = args[1] == 0 or args[0].nullable
        _TABLE[key] = n
    return n


EMPTY = _mk("empty")      # matches nothing
EPS = _mk("eps")          # matches the empty string


def chars(allowed: str, negate: bool = False) -> Node:
    return _mk("chars", frozenset(allowed), negate)


def _seq2(a: Node, b: Node) -> Node:
    if a is EMPTY or b is EMPTY:
        return EMPTY
    if a is EPS:
        return b
    if b is EPS:
        return a
    if a.kind == "seq":                      # keep sequences right-nested
        return _seq2(a.args[0], _seq2(a.args[1], b))
    return _mk("seq", a, b)


def seq(*parts: Node) -> Node:
    out = EPS
    for p in reversed(parts):
        out = _seq2(p, out)
    return out


def alt(*options: Node) -> Node:
    flat: set[Node] = set()
    for o in options:
        if o.kind == "alt":
            flat |= o.args[0]
        elif o is not EMPTY:
            flat.add(o)
    if not flat:
        return EMPTY
    if len(flat) == 1:
        return next(iter(flat))
    return _mk("alt", frozenset(flat))


def rep(x: Node, lo: int = 0, hi: int | None = None) -> Node:
    """x repeated between lo and hi times (hi=None means unbounded)."""
    if hi == 0 or x is EPS:
        return EPS
    if x is EMPTY:
        return EPS if lo == 0 else EMPTY
    return _mk("rep", x, lo, hi)


def lit(text: str) -> Node:
    return seq(*[chars(c) for c in text])


def one_of(strings) -> Node:
    """Alternation of literals, built as a trie so that shared prefixes are shared."""
    strings = set(strings)
    heads: dict[str, set[str]] = {}
    for s in strings:
        if s:
            heads.setdefault(s[0], set()).add(s[1:])
    branches = [seq(chars(c), one_of(rest)) for c, rest in heads.items()]
    if "" in strings:
        branches.append(EPS)
    return alt(*branches)


def deriv(n: Node, ch: str) -> Node:
    """The language of n after consuming the character ch."""
    d = n._deriv.get(ch)
    if d is not None:
        return d
    k = n.kind
    if k in ("empty", "eps"):
        d = EMPTY
    elif k == "chars":
        d = EPS if (ch in n.args[0]) != n.args[1] else EMPTY
    elif k == "seq":
        a, b = n.args
        d = _seq2(deriv(a, ch), b)
        if a.nullable:
            d = alt(d, deriv(b, ch))
    elif k == "alt":
        d = alt(*[deriv(o, ch) for o in n.args[0]])
    else:  # rep
        x, lo, hi = n.args
        d = _seq2(deriv(x, ch), rep(x, max(lo - 1, 0), None if hi is None else hi - 1))
    n._deriv[ch] = d
    return d


def advance(state: Node, text: str) -> Node:
    """State after consuming `text`; EMPTY if `text` cannot continue a valid output."""
    for ch in text:
        state = deriv(state, ch)
        if state is EMPTY:
            return EMPTY
    return state


def matches(pattern: Node, text: str) -> bool:
    return advance(pattern, text).nullable
