"""Constrained token generation via logit masking (paper Eq. 5)."""
from __future__ import annotations
from typing import Callable, Sequence
import numpy as np
from .automaton import EMPTY, Node, advance

EOS = "<eos>"


class TokenMask:
    """Binary validity mask M(x_t) over a vocabulary of token strings.

    A token is valid if appending its text keeps the output a prefix of some string
    accepted by the schema automaton. EOS is valid only once the output is complete.
    """

    def __init__(self, vocab: Sequence[str], pattern: Node, eos_token: str = EOS):
        self.vocab = list(vocab)
        self.eos = eos_token
        self.state = pattern
        self._cache: dict[Node, np.ndarray] = {}

    def mask(self) -> np.ndarray:
        m = self._cache.get(self.state)
        if m is None:
            m = np.zeros(len(self.vocab), dtype=bool)
            for i, tok in enumerate(self.vocab):
                if tok == self.eos:
                    m[i] = self.state.nullable
                elif tok:
                    m[i] = advance(self.state, tok) is not EMPTY
            self._cache[self.state] = m
        return m

    def consume(self, token: str) -> None:
        if token != self.eos:
            self.state = advance(self.state, token)

    @property
    def complete(self) -> bool:
        return self.state.nullable


def masked_distribution(logits: np.ndarray, mask: np.ndarray, temperature: float = 0.0,
                        top_p: float = 1.0) -> np.ndarray:
    """P(x_t | x_<t) of Eq. 5: softmax(z / tau) restricted to the nucleus V' and
    multiplied by M, then renormalized.

    At tau = 0 the distribution is a point mass on the highest masked logit, with
    ties broken toward the highest vocabulary index (the rule stated in the paper).
    """
    logits = np.asarray(logits, dtype=np.float64)
    if not mask.any():
        raise RuntimeError("no valid token: the mask is empty")
    p = np.zeros_like(logits)
    if temperature <= 0.0:
        z = np.where(mask, logits, -np.inf)
        best = np.flatnonzero(z == z.max())[-1]
        p[best] = 1.0
        return p
    z = logits / temperature
    q = np.exp(z - z.max())
    q /= q.sum()
    keep = np.ones_like(mask)
    if top_p < 1.0:                               # nucleus V' (Eq. 4)
        order = np.argsort(-q, kind="stable")
        cutoff = int(np.searchsorted(np.cumsum(q[order]), top_p)) + 1
        keep = np.zeros_like(mask)
        keep[order[:cutoff]] = True
        if not (keep & mask).any():               # keep the best valid token reachable
            keep[np.flatnonzero(mask)[np.argmax(q[mask])]] = True
    p = q * mask * keep
    return p / p.sum()


def constrained_decode(logits_fn: Callable[[str], np.ndarray], vocab: Sequence[str], pattern: Node, *,
                       temperature: float = 0.0, top_p: float = 1.0, max_steps: int = 2048,
                       rng: np.random.Generator | None = None, eos_token: str = EOS) -> str:
    """Generate text that the schema automaton accepts.

    ``logits_fn(prefix)`` returns unnormalized logits over ``vocab`` for the next
    token; in production it wraps the LLM forward pass.
    """
    tracker = TokenMask(vocab, pattern, eos_token)
    out = ""
    for _ in range(max_steps):
        p = masked_distribution(logits_fn(out), tracker.mask(), temperature, top_p)
        if temperature <= 0.0:
            idx = int(p.argmax())
        else:
            idx = int((rng or np.random.default_rng()).choice(len(p), p=p))
        tok = tracker.vocab[idx]
        if tok == eos_token:
            return out
        out += tok
        tracker.consume(tok)
    if tracker.complete:
        return out
    raise RuntimeError("max_steps reached before the output was complete")
