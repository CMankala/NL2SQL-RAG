"""Compile a (subset of) JSON Schema to the automaton used for logit masking.

Supported: ``enum`` / ``const``, ``integer``, ``boolean``, ``string`` (with
``maxLength``), ``array`` (``minItems`` / ``maxItems``), ``object`` and ``anyOf``.
Outputs are canonical JSON: no insignificant whitespace, and every declared object
property present in declaration order. Free-text strings exclude quotes, backslashes
and control characters, so no escaping is needed; that is sufficient for identifiers
and simple filter values. A production deployment can swap this module for a general
engine such as XGrammar or Outlines without touching the rest of the pipeline.
"""
from __future__ import annotations
import json
from .automaton import Node, alt, chars, lit, one_of, rep, seq, EPS

_DIGITS = "0123456789"
INTEGER = seq(rep(chars("-"), 0, 1), alt(chars("0"), seq(chars("123456789"), rep(chars(_DIGITS), 0, 17))))
_FORBIDDEN_IN_STRING = '"\\' + "".join(chr(i) for i in range(32))


def _json(value) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def compile_schema(schema: dict) -> Node:
    if "const" in schema:
        return lit(_json(schema["const"]))
    if "enum" in schema:
        return one_of(_json(v) for v in schema["enum"])
    if "anyOf" in schema:
        return alt(*[compile_schema(s) for s in schema["anyOf"]])
    kind = schema.get("type")
    if kind == "integer":
        return INTEGER
    if kind == "boolean":
        return one_of(["true", "false"])
    if kind == "string":
        body = rep(chars(_FORBIDDEN_IN_STRING, negate=True), schema.get("minLength", 0), schema.get("maxLength", 64))
        return seq(chars('"'), body, chars('"'))
    if kind == "array":
        item = compile_schema(schema["items"])
        lo, hi = schema.get("minItems", 0), schema.get("maxItems", 8)
        if hi < 1:
            return lit("[]")
        tail = rep(seq(chars(","), item), max(lo - 1, 0), hi - 1)
        inner = seq(item, tail)
        return seq(chars("["), inner if lo > 0 else alt(EPS, inner), chars("]"))
    if kind == "object":
        parts = [chars("{")]
        for i, (key, sub) in enumerate(schema.get("properties", {}).items()):
            parts.append(lit(("," if i else "") + _json(key) + ":"))
            parts.append(compile_schema(sub))
        parts.append(chars("}"))
        return seq(*parts)
    raise ValueError(f"unsupported JSON schema fragment: {schema!r}")


def compile_tool_call(tools: list[dict]) -> Node:
    """Automaton for ``{"name":<tool>,"arguments":{...}}`` over a tool catalog."""
    if not tools:
        raise ValueError("the tool catalog is empty")
    return alt(*[
        seq(lit('{"name":' + _json(t["name"]) + ',"arguments":'), compile_schema(t["inputSchema"]), chars("}"))
        for t in tools
    ])
