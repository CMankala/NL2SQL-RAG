"""Optional adapter: apply the schema mask inside Hugging Face ``generate``.

Requires ``torch`` and ``transformers`` (not installed by default). Usage::

    from transformers import AutoModelForCausalLM, AutoTokenizer, LogitsProcessorList
    tok = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-Coder-32B-Instruct")
    model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-Coder-32B-Instruct", device_map="auto")
    proc = SchemaLogitsProcessor(tok, compile_tool_call(tools), prompt_length=inputs.input_ids.shape[1])
    model.generate(**inputs, do_sample=False, logits_processor=LogitsProcessorList([proc]))

This adapter is provided for integration and is not covered by the test suite,
which runs without model weights.
"""
from __future__ import annotations
from .automaton import Node
from .masking import TokenMask

try:  # pragma: no cover - optional dependency
    import torch
    from transformers import LogitsProcessor
except ImportError:  # pragma: no cover
    torch = None
    LogitsProcessor = object


class SchemaLogitsProcessor(LogitsProcessor):  # pragma: no cover - needs model weights
    def __init__(self, tokenizer, pattern: Node, prompt_length: int):
        if torch is None:
            raise ImportError("SchemaLogitsProcessor requires torch and transformers")
        self.tokenizer = tokenizer
        self.pattern = pattern
        self.prompt_length = prompt_length
        size = len(tokenizer)
        special = set(tokenizer.all_special_ids)
        self.vocab = ["" if i in special else tokenizer.decode([i]) for i in range(size)]
        self.eos_id = tokenizer.eos_token_id
        self.vocab[self.eos_id] = "<eos>"

    def __call__(self, input_ids, scores):
        for row in range(input_ids.shape[0]):
            tracker = TokenMask(self.vocab, self.pattern)
            tracker.consume(self.tokenizer.decode(input_ids[row, self.prompt_length:], skip_special_tokens=True))
            allowed = torch.from_numpy(tracker.mask()).to(scores.device)
            scores[row, ~allowed[: scores.shape[1]]] = float("-inf")
        return scores
