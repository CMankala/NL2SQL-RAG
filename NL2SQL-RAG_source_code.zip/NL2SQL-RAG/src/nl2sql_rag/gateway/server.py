"""Minimal MCP-style tool server speaking JSON-RPC 2.0.

It implements the three methods the pipeline needs (``initialize``, ``tools/list``
and ``tools/call``) in-process or over stdio. It follows the MCP message shapes but
is not a full implementation of the protocol; for deployment behind a standard MCP
host, register the same tool schemas and handler with the official MCP SDK.
"""
from __future__ import annotations
import json
import sys
from ..catalog import Catalog
from ..compiler.glsl import GLSLCompiler, ValidationError, to_sql
from .automaton import matches
from .schema import compile_schema
from .tools import build_tools

PROTOCOL_VERSION = "2024-11-05"


class ToolServer:
    def __init__(self, catalog: Catalog, connection=None, placeholder: str = "?"):
        self.catalog = catalog
        self.connection = connection          # any DB-API 2.0 connection, or None for compile-only
        self.placeholder = placeholder
        self.compiler = GLSLCompiler(catalog)

    def tools(self, tables=None) -> list[dict]:
        return build_tools(self.catalog, list(self.catalog.tables) if tables is None else tables)

    def call(self, name: str, arguments: dict, tables=None) -> dict:
        """Validate against the registered schema, compile, and execute."""
        tool = next((t for t in self.tools(tables) if t["name"] == name), None)
        if tool is None:
            raise ValidationError(f"unknown tool {name!r}", name)
        canonical = json.dumps(arguments, separators=(",", ":"), ensure_ascii=False)
        if not matches(compile_schema(tool["inputSchema"]), canonical):
            raise ValidationError(f"arguments do not conform to the schema of {name!r}")
        sql, params = to_sql(self.compiler.compile(name, arguments), self.placeholder)
        result = {"sql": sql, "params": params}
        if self.connection is not None:
            cur = self.connection.cursor()
            cur.execute(sql, params)
            result["columns"] = [d[0] for d in cur.description]
            result["rows"] = [list(r) for r in cur.fetchall()]
        return result

    # ---- JSON-RPC 2.0 ----
    def handle(self, request: dict) -> dict | None:
        rid, method, params = request.get("id"), request.get("method"), request.get("params") or {}
        try:
            if method == "initialize":
                result = {"protocolVersion": PROTOCOL_VERSION, "capabilities": {"tools": {}},
                          "serverInfo": {"name": "nl2sql-rag", "version": "1.0.0"}}
            elif method == "tools/list":
                result = {"tools": self.tools()}
            elif method == "tools/call":
                payload = self.call(params.get("name"), params.get("arguments") or {})
                result = {"content": [{"type": "text", "text": json.dumps(payload, default=str)}], "isError": False}
            elif rid is None:
                return None                                  # notification
            else:
                return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": f"method not found: {method}"}}
        except ValidationError as exc:
            result = {"content": [{"type": "text", "text": str(exc)}], "isError": True}
        return None if rid is None else {"jsonrpc": "2.0", "id": rid, "result": result}

    def serve_stdio(self, stdin=sys.stdin, stdout=sys.stdout) -> None:
        for line in stdin:
            line = line.strip()
            if not line:
                continue
            try:
                response = self.handle(json.loads(line))
            except json.JSONDecodeError:
                response = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "parse error"}}
            if response is not None:
                stdout.write(json.dumps(response) + "\n")
                stdout.flush()
