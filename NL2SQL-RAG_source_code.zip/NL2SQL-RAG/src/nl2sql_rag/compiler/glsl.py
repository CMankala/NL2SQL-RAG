"""Global-Local Schema Linking (GL-SL) compiler: validated tool call -> SQL AST -> SQL.

Global pruning keeps only the tables needed to connect the referenced columns along
FK-PK paths. Local alignment binds each parameter label to a canonical column through
a trie. AST compilation emits parameterized ANSI SQL; no SQL text comes from the LLM.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from ..catalog import Catalog, ForeignKey

MAX_LIMIT = 10_000


class ValidationError(Exception):
    """A tool call that cannot be compiled; `identifier` names the offending element."""

    def __init__(self, message: str, identifier: str | None = None):
        super().__init__(message)
        self.identifier = identifier


# --------------------------- local alignment ---------------------------
class ColumnTrie:
    """Case-insensitive trie over canonical ``table.column`` identifiers."""

    def __init__(self, catalog: Catalog):
        self.root: dict = {}
        for name in catalog.qualified_columns():
            node = self.root
            for ch in name.lower():
                node = node.setdefault(ch, {})
            node["$"] = name

    def resolve(self, label: str) -> tuple[str, str]:
        node = self.root
        for ch in label.lower():
            node = node.get(ch)
            if node is None:
                raise ValidationError(f"unknown column {label!r}", label)
        canonical = node.get("$")
        if canonical is None:
            raise ValidationError(f"{label!r} is not a complete column identifier", label)
        table, column = canonical.split(".", 1)
        return table, column


# ------------------------------- AST -----------------------------------
@dataclass(frozen=True)
class Col:
    table: str
    column: str


@dataclass(frozen=True)
class Agg:
    function: str
    arg: Col


@dataclass(frozen=True)
class Predicate:
    column: Col
    op: str
    value: object


@dataclass(frozen=True)
class Join:
    table: str
    on: ForeignKey


@dataclass
class Select:
    projections: list
    from_table: str
    joins: list[Join] = field(default_factory=list)
    where: list[Predicate] = field(default_factory=list)
    group_by: list[Col] = field(default_factory=list)
    order_by: list[tuple[Col, str]] = field(default_factory=list)
    limit: int | None = None


_OPS = {"=": "=", "!=": "<>", "<": "<", "<=": "<=", ">": ">", ">=": ">=", "like": "LIKE"}
_AGGS = {"count": "COUNT", "sum": "SUM", "avg": "AVG", "min": "MIN", "max": "MAX"}


def _q(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _col(c: Col) -> str:
    return f"{_q(c.table)}.{_q(c.column)}"


def to_sql(ast: Select, placeholder: str = "?") -> tuple[str, list]:
    """Render the AST as parameterized ANSI SQL. Use ``placeholder="%s"`` for psycopg."""
    params: list = []
    proj = [f"{_AGGS[p.function]}({_col(p.arg)})" if isinstance(p, Agg) else _col(p) for p in ast.projections]
    sql = [f"SELECT {', '.join(proj)}", f"FROM {_q(ast.from_table)}"]
    for j in ast.joins:
        fk = j.on
        sql.append(f"JOIN {_q(j.table)} ON {_q(fk.table)}.{_q(fk.column)} = {_q(fk.ref_table)}.{_q(fk.ref_column)}")
    if ast.where:
        conds = []
        for p in ast.where:
            conds.append(f"{_col(p.column)} {_OPS[p.op]} {placeholder}")
            params.append(p.value)
        sql.append("WHERE " + " AND ".join(conds))
    if ast.group_by:
        sql.append("GROUP BY " + ", ".join(_col(c) for c in ast.group_by))
    if ast.order_by:
        sql.append("ORDER BY " + ", ".join(f"{_col(c)} {d.upper()}" for c, d in ast.order_by))
    if ast.limit is not None:
        sql.append(f"LIMIT {int(ast.limit)}")
    return "\n".join(sql), params


# ----------------------------- compiler --------------------------------
class GLSLCompiler:
    def __init__(self, catalog: Catalog):
        self.catalog = catalog
        self.trie = ColumnTrie(catalog)

    def _column(self, label) -> Col:
        if not isinstance(label, str):
            raise ValidationError(f"column must be a string, got {label!r}")
        return Col(*self.trie.resolve(label))

    def _predicates(self, filters) -> list[Predicate]:
        out = []
        for f in filters or []:
            if f.get("op") not in _OPS:
                raise ValidationError(f"unsupported operator {f.get('op')!r}")
            value = f.get("value")
            if isinstance(value, bool) or not isinstance(value, (int, str)):
                raise ValidationError(f"unsupported filter value {value!r}")
            out.append(Predicate(self._column(f.get("column")), f["op"], value))
        return out

    def _plan_joins(self, tables: list[str]) -> tuple[str, list[Join]]:
        """Global pruning: connect the referenced tables with shortest FK paths
        (a greedy Steiner-tree approximation) and drop everything else."""
        base, joined, joins = tables[0], {tables[0]}, []
        for target in tables[1:]:
            path = self.catalog.fk_path(joined, target)
            if path is None:
                raise ValidationError(f"no FK path connects {target!r} to {base!r}", target)
            for _, nxt, fk in path:
                if nxt not in joined:
                    joins.append(Join(nxt, fk))
                    joined.add(nxt)
        return base, joins

    @staticmethod
    def _limit(value) -> int | None:
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValidationError(f"limit must be a non-negative integer, got {value!r}")
        return min(value, MAX_LIMIT)

    def compile(self, name: str, args: dict) -> Select:
        if name == "select_rows":
            cols = [self._column(c) for c in args.get("columns") or []]
            if not cols:
                raise ValidationError("select_rows needs at least one column")
            where = self._predicates(args.get("filters"))
            order = []
            for o in args.get("order_by") or []:
                if o.get("direction") not in ("asc", "desc"):
                    raise ValidationError(f"bad sort direction {o.get('direction')!r}")
                order.append((self._column(o.get("column")), o["direction"]))
            used = cols + [p.column for p in where] + [c for c, _ in order]
            base, joins = self._plan_joins(list(dict.fromkeys(c.table for c in used)))
            return Select(cols, base, joins, where, [], order, self._limit(args.get("limit")))
        if name == "aggregate":
            metrics = []
            for m in args.get("metrics") or []:
                if m.get("function") not in _AGGS:
                    raise ValidationError(f"unsupported aggregate {m.get('function')!r}")
                metrics.append(Agg(m["function"], self._column(m.get("column"))))
            if not metrics:
                raise ValidationError("aggregate needs at least one metric")
            groups = [self._column(c) for c in args.get("group_by") or []]
            where = self._predicates(args.get("filters"))
            used = groups + [m.arg for m in metrics] + [p.column for p in where]
            base, joins = self._plan_joins(list(dict.fromkeys(c.table for c in used)))
            return Select(groups + metrics, base, joins, where, groups, [], self._limit(args.get("limit")))
        raise ValidationError(f"unknown tool {name!r}", name)
