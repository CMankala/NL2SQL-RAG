"""Token scorers that play the role of the LLM in tests and in the demo."""
from __future__ import annotations
from typing import Sequence
import numpy as np
from .gateway.masking import EOS

_STRUCTURE = ['{"name":"', '","arguments":{', '"columns":[', '"filters":[', '"order_by":[', '"metrics":[',
              '"group_by":[', '"limit":', '{"column":"', '","op":"', '","value":', '","direction":"',
              '{"function":"', '","column":"', '"},', '"}', '],', ']', '}', ',', '"']


def build_vocabulary(identifiers: Sequence[str] = ()) -> list[str]:
    """A small string vocabulary: printable ASCII, JSON fragments, identifiers, EOS."""
    vocab = [chr(i) for i in range(32, 127)]
    for tok in list(_STRUCTURE) + list(identifiers):
        if tok not in vocab:
            vocab.append(tok)
    return vocab + [EOS]


class ScriptedLLM:
    """Deterministic test double for the LLM.

    It is given ranked candidate outputs (most preferred first) and scores each token
    by how far it advances the best candidate consistent with the text so far. A
    preferred candidate may be invalid (for example, it may name a column that does not
    exist); the mask then removes its tokens and decoding continues along the next
    candidate, which is how the effect of the constraint is demonstrated without model
    weights. It is not a language model and is not used to produce the paper's results.
    """

    def __init__(self, vocab: Sequence[str], candidates: Sequence[str]):
        self.vocab, self.candidates = list(vocab), list(candidates)

    def __call__(self, prefix: str) -> np.ndarray:
        logits = np.zeros(len(self.vocab))
        for rank, cand in enumerate(self.candidates):
            if not cand.startswith(prefix):
                continue
            rest, weight = cand[len(prefix):], 1.0 / (rank + 1)
            for i, tok in enumerate(self.vocab):
                if tok == EOS:
                    score = 1.0 if not rest else 0.0
                else:
                    score = float(len(tok)) if rest.startswith(tok) else 0.0
                logits[i] = max(logits[i], weight * score)
        return logits
