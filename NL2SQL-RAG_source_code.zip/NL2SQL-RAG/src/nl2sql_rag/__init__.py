"""Reference implementation of the pipeline in
"Making Enterprise NL2SQL Reliable: MCP, Constrained Decoding, and Hybrid RAG"."""
__version__ = "1.0.0"
