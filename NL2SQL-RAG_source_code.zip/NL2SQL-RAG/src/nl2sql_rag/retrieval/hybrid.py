"""Sparse-dense hybrid retrieval with an entropy-adaptive weight (paper Eqs. 1-3)."""
from __future__ import annotations
import math
import re
import zlib
import numpy as np
from ..catalog import Chunk

_WORD = re.compile(r"[A-Za-z]+|\d+")


def tokenize(text: str) -> list[str]:
    """Lower-cased words; snake_case and camelCase identifiers are split."""
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text)
    return [w.lower() for w in _WORD.findall(text)]


class HashingEmbedder:
    """Dependency-free dense encoder (hashed words and character trigrams).

    It stands in for the bi-encoder E_dense so that the package runs without model
    downloads. Any object with an ``encode(list[str]) -> np.ndarray`` method (for
    example a sentence-transformers model) can be passed to HybridIndex instead.
    """

    def __init__(self, dim: int = 512):
        self.dim = dim

    def _features(self, text: str):
        for w in tokenize(text):
            yield "w:" + w
            padded = f"#{w}#"
            for i in range(len(padded) - 2):
                yield "g:" + padded[i:i + 3]

    def encode(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float64)
        for r, text in enumerate(texts):
            for f in self._features(text):
                h = zlib.crc32(f.encode())
                out[r, h % self.dim] += 1.0 if (h >> 16) & 1 else -1.0
        return out


class BM25:
    """Okapi BM25 over tokenized chunks."""

    def __init__(self, docs: list[list[str]], k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs = docs
        self.len = np.array([len(d) for d in docs], dtype=np.float64)
        self.avg = float(self.len.mean()) if len(docs) else 0.0
        self.tf: list[dict[str, int]] = []
        df: dict[str, int] = {}
        for d in docs:
            counts: dict[str, int] = {}
            for w in d:
                counts[w] = counts.get(w, 0) + 1
            self.tf.append(counts)
            for w in counts:
                df[w] = df.get(w, 0) + 1
        n = len(docs)
        self.idf = {w: math.log(1 + (n - f + 0.5) / (f + 0.5)) for w, f in df.items()}

    def scores(self, query: list[str]) -> np.ndarray:
        s = np.zeros(len(self.docs))
        for i, counts in enumerate(self.tf):
            norm = self.k1 * (1 - self.b + self.b * self.len[i] / (self.avg or 1.0))
            for w in query:
                f = counts.get(w, 0)
                if f:
                    s[i] += self.idf[w] * f * (self.k1 + 1) / (f + norm)
        return s


class HybridIndex:
    """Score(Q, C) = alpha * CosSim(Q, C) + (1 - alpha) * BM25(Q, C)   (Eq. 2)

    with alpha = alpha0 * (1 - H(Q) / log|C|), where H(Q) is the Shannon entropy of
    softmax(v_Q . M^T / T_s) over the chunk matrix M (Eq. 3). BM25 scores are min-max
    normalized to [0, 1] per query.
    """

    def __init__(self, chunks: list[Chunk], embedder=None, alpha0: float = 0.75,
                 softmax_temperature: float = 0.05):
        self.chunks = chunks
        self.embedder = embedder or HashingEmbedder()
        self.alpha0 = alpha0
        self.ts = softmax_temperature
        self.M = self._normalize(np.asarray(self.embedder.encode([c.text for c in chunks]), dtype=np.float64))
        self.bm25 = BM25([tokenize(c.text) for c in chunks])

    @staticmethod
    def _normalize(m: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(m, axis=-1, keepdims=True)
        return m / np.where(norms == 0, 1.0, norms)

    def entropy(self, cos: np.ndarray) -> float:
        z = cos / self.ts
        z = z - z.max()
        p = np.exp(z)
        p /= p.sum()
        nz = p[p > 0]
        return float(-(nz * np.log(nz)).sum())

    def alpha(self, cos: np.ndarray) -> float:
        n = len(self.chunks)
        if n < 2:
            return self.alpha0
        return self.alpha0 * (1.0 - self.entropy(cos) / math.log(n))

    def score(self, query: str) -> tuple[np.ndarray, float]:
        """Hybrid score of `query` against every chunk, and the alpha that was used."""
        v = self._normalize(np.asarray(self.embedder.encode([query]), dtype=np.float64))[0]
        cos = self.M @ v                                   # Eq. 1 (rows are unit vectors)
        sparse = self.bm25.scores(tokenize(query))
        lo, hi = sparse.min(), sparse.max()
        sparse = (sparse - lo) / (hi - lo) if hi > lo else np.zeros_like(sparse)
        a = self.alpha(cos)
        return a * cos + (1 - a) * sparse, a
