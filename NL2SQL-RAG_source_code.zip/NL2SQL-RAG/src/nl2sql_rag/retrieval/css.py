"""Collective Schema Subsetting (paper Algorithm 1)."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable
from ..catalog import Catalog
from .hybrid import HybridIndex, tokenize

_STOP = set("a an the of for to in on at by with and or from is are was were be how many much what which "
            "who whose list show give find get all each per than that this their its have has had do does "
            "did most least more less over under between into as not no".split())


def heuristic_virtual_schema(question: str) -> list[str]:
    """Stand-in for Phase 1 when no LLM is supplied: content words and adjacent pairs.

    In the paper, Phase 1 prompts the LLM with 8 in-context examples to emit virtual
    ``table.column`` tokens without seeing real identifiers; pass such a callable as
    ``virtual_schema_fn`` to reproduce that behaviour.
    """
    words = [w for w in tokenize(question) if w not in _STOP]
    pairs = [f"{a} {b}" for a, b in zip(words, words[1:])]
    return list(dict.fromkeys(words + pairs))


@dataclass
class GroundedContext:
    """The grounded context set G."""
    elements: list[tuple[str, float]]            # (chunk id, score), top-k after de-duplication
    tables: list[str]                            # tables of the elements plus FK expansion
    virtual_tokens: list[str] = field(default_factory=list)

    @property
    def element_ids(self) -> list[str]:
        return [e for e, _ in self.elements]


def collective_schema_subsetting(
    question: str, catalog: Catalog, index: HybridIndex, *,
    theta: float = 0.62, k: int = 40, h: int = 1,
    virtual_schema_fn: Callable[[str], list[str]] = heuristic_virtual_schema,
    negative: frozenset[str] = frozenset(),
) -> GroundedContext:
    """Run CSS and return G.

    ``negative`` holds chunk ids excluded by earlier validation failures (the
    "negative constraints" that the orchestrator appends on a retry).
    """
    # Phase 1 - abstract grammar generation
    virtual = virtual_schema_fn(question)
    # Phase 2 - schema grounding: keep the best chunk per token if it clears theta
    grounded: dict[str, float] = {}
    for token in virtual:
        scores, _ = index.score(token)
        order = scores.argsort()[::-1]
        best = next((i for i in order if index.chunks[i].id not in negative), None)
        if best is None or scores[best] < theta:
            continue
        cid = index.chunks[best].id
        # Phase 3a - de-duplicate, retaining the highest score per chunk
        grounded[cid] = max(grounded.get(cid, float("-inf")), float(scores[best]))
    # Phase 3b - top-k
    elements = sorted(grounded.items(), key=lambda kv: (-kv[1], kv[0]))[:k]
    # Phase 3c - expand along foreign keys by up to h hops
    anchors = list(dict.fromkeys(cid.split(".")[0] for cid, _ in elements))
    reach = catalog.within_hops(anchors, h)
    tables = anchors + [t for t in catalog.tables if t in reach and t not in anchors]
    return GroundedContext(elements, tables, virtual)
