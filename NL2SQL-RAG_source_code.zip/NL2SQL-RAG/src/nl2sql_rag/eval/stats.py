"""Interval estimates used in the paper (Wilson and Newcombe, 95% by default)."""
from __future__ import annotations
import math


def wilson_interval(p: float, n: int, z: float = 1.959964) -> tuple[float, float]:
    """Wilson score interval for a proportion p observed on n items."""
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return centre - half, centre + half


def newcombe_interval(p1: float, n1: int, p2: float, n2: int, z: float = 1.959964) -> tuple[float, float]:
    """Newcombe hybrid-score interval for p1 - p2 (independent samples)."""
    l1, u1 = wilson_interval(p1, n1, z)
    l2, u2 = wilson_interval(p2, n2, z)
    d = p1 - p2
    return d - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
