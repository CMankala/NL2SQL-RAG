"""Evaluation metrics: EX, VES, SER and SHR."""
from __future__ import annotations
import math
import re
from collections import Counter
from ..catalog import Catalog


def execution_match(pred_rows, gold_rows) -> bool:
    """True if two result sets are equal as multisets of rows."""
    norm = lambda rows: Counter(tuple(r) for r in rows)
    return pred_rows is not None and norm(pred_rows) == norm(gold_rows)


def execution_accuracy(matches: list[bool]) -> float:
    return sum(matches) / len(matches) if matches else 0.0


def valid_efficiency_score(matches: list[bool], ref_times: list[float], gen_times: list[float]) -> float:
    """VES: mean over questions of [correct] * sqrt(T_ref / T_gen)."""
    if not matches:
        return 0.0
    return sum(math.sqrt(r / g) for ok, r, g in zip(matches, ref_times, gen_times) if ok and g > 0) / len(matches)


def schema_element_recall(gold_elements: list[set[str]], contexts: list[set[str]]) -> float:
    """SER: fraction of gold-SQL schema elements present in the context passed to the generator."""
    total = sum(len(g) for g in gold_elements)
    hit = sum(len(g & c) for g, c in zip(gold_elements, contexts))
    return hit / total if total else 1.0


_QUALIFIED = re.compile(r'"?([A-Za-z_][A-Za-z0-9_]*)"?\s*\.\s*"?([A-Za-z_][A-Za-z0-9_]*)"?')


def referenced_columns(sql: str) -> set[str]:
    """Qualified ``table.column`` references in a SQL string.

    A lightweight extractor for automated screening; table aliases are not resolved.
    The paper's SHR was validated by two annotators.
    """
    return {f"{t}.{c}" for t, c in _QUALIFIED.findall(sql)}


def tool_call_columns(arguments: dict) -> set[str]:
    """Identifier-valued parameters of a tool call (filter values are data, not identifiers)."""
    cols = set(arguments.get("columns") or []) | set(arguments.get("group_by") or [])
    for key in ("filters", "order_by", "metrics"):
        cols |= {item["column"] for item in arguments.get(key) or []}
    return cols


def is_structural_hallucination(identifiers: set[str], catalog: Catalog) -> bool:
    """True if any referenced ``table.column`` is absent from the catalog."""
    return any(not catalog.has_column(*i.split(".", 1)) for i in identifiers)


def structural_hallucination_rate(outputs: list[set[str]], catalog: Catalog) -> float:
    """SHR: fraction of outputs that reference at least one non-existent schema element."""
    return sum(is_structural_hallucination(o, catalog) for o in outputs) / len(outputs) if outputs else 0.0
