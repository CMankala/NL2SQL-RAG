"""End-to-end demo on an in-memory SQLite database (no model weights required).

    python examples/demo.py

The LLM is replaced by ScriptedLLM, a deterministic scorer. In the second question
its preferred output names a column that does not exist; the logit mask removes that
continuation and decoding proceeds with the next candidate.
"""
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from nl2sql_rag.catalog import Catalog, ForeignKey, Table
from nl2sql_rag.llm import ScriptedLLM, build_vocabulary
from nl2sql_rag.orchestration.pipeline import Pipeline

DDL = """
CREATE TABLE customers (customer_id INTEGER PRIMARY KEY, name TEXT, country TEXT);
CREATE TABLE products  (product_id INTEGER PRIMARY KEY, title TEXT, category TEXT, price INTEGER);
CREATE TABLE orders    (order_id INTEGER PRIMARY KEY, customer_id INTEGER REFERENCES customers, order_date TEXT);
CREATE TABLE order_items (order_id INTEGER REFERENCES orders, product_id INTEGER REFERENCES products, quantity INTEGER);
CREATE TABLE warehouses (warehouse_id INTEGER PRIMARY KEY, city TEXT);
INSERT INTO customers VALUES (1,'Ada','Italy'),(2,'Grace','Brazil'),(3,'Linus','Italy');
INSERT INTO products VALUES (10,'Laptop','computers',1200),(11,'Mouse','accessories',25),(12,'Monitor','computers',300);
INSERT INTO orders VALUES (100,1,'2026-01-05'),(101,2,'2026-01-07'),(102,1,'2026-02-11');
INSERT INTO order_items VALUES (100,10,1),(100,11,2),(101,12,1),(102,11,5);
INSERT INTO warehouses VALUES (1,'Messina'),(2,'Villanova');
"""

CATALOG = Catalog(
    [
        Table("customers", {"customer_id": "integer", "name": "text", "country": "text"},
              "people who place orders", {"name": "customer name", "country": "country of residence"}),
        Table("products", {"product_id": "integer", "title": "text", "category": "text", "price": "integer"},
              "items for sale", {"title": "product title", "category": "product category", "price": "unit price"}),
        Table("orders", {"order_id": "integer", "customer_id": "integer", "order_date": "text"},
              "purchase orders", {"order_date": "date the order was placed"}),
        Table("order_items", {"order_id": "integer", "product_id": "integer", "quantity": "integer"},
              "line items of an order", {"quantity": "units ordered"}),
        Table("warehouses", {"warehouse_id": "integer", "city": "text"}, "storage sites", {"city": "warehouse city"}),
    ],
    [
        ForeignKey("orders", "customer_id", "customers", "customer_id"),
        ForeignKey("order_items", "order_id", "orders", "order_id"),
        ForeignKey("order_items", "product_id", "products", "product_id"),
    ],
)


def call(name, **arguments):
    return json.dumps({"name": name, "arguments": arguments}, separators=(",", ":"))


# question -> ranked candidate outputs of the scripted "LLM" (most preferred first)
QUESTIONS = {
    "Which customers live in Italy?": [
        call("select_rows", columns=["customers.name"],
             filters=[{"column": "customers.country", "op": "=", "value": "Italy"}], order_by=[], limit=10),
    ],
    "Total quantity ordered per product category": [
        # preferred output hallucinates `products.product_category`
        call("aggregate", metrics=[{"function": "sum", "column": "order_items.quantity"}],
             group_by=["products.product_category"], filters=[], limit=10),
        call("aggregate", metrics=[{"function": "sum", "column": "order_items.quantity"}],
             group_by=["products.category"], filters=[], limit=10),
    ],
    "Names of customers and the titles of products they ordered": [
        call("select_rows", columns=["customers.name", "products.title"], filters=[],
             order_by=[{"column": "customers.name", "direction": "asc"}], limit=10),
    ],
}


def main():
    conn = sqlite3.connect(":memory:")
    conn.executescript(DDL)
    vocab = build_vocabulary(CATALOG.qualified_columns())
    # theta is tuned to the encoder; the demo uses the dependency-free hashing encoder
    pipe = Pipeline(CATALOG, vocab, lambda q, ctx, tools: ScriptedLLM(vocab, QUESTIONS[q]),
                    connection=conn, theta=0.30, k=40, h=1)
    for question in QUESTIONS:
        state = pipe.run(question)
        print("=" * 78)
        print("Q:", question)
        print("grounded elements:", ", ".join(state.context.element_ids))
        print("tables in G      :", ", ".join(state.context.tables))
        print("tool call        :", json.dumps(state.tool_params))
        print("status           :", state.status)
        if state.result:
            print("SQL:\n  " + state.result["sql"].replace("\n", "\n  "))
            print("params:", state.result["params"])
            print("rows  :", state.result["rows"])


if __name__ == "__main__":
    main()
