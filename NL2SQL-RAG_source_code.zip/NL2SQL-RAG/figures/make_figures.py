"""Regenerate Figs. 2-4 of the paper from the CSV files in results/.

Usage (from the repository root):
    python figures/make_figures.py
"""
import csv
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator

ROOT = Path(__file__).resolve().parent.parent
out = str(ROOT / "figures")


def rows(name):
    with open(ROOT / "results" / name, newline="") as fh:
        return list(csv.DictReader(fh))


def series(name, key, cast=float):
    return [cast(r[key]) for r in rows(name)]

plt.rcParams.update({"font.family":"STIXGeneral","mathtext.fontset":"stix","font.size":8,
 "axes.linewidth":0.6,"axes.edgecolor":"#898781","xtick.color":"#52514e","ytick.color":"#52514e",
 "axes.labelcolor":"#0b0b0b","xtick.major.width":0.5,"ytick.major.width":0.5,"pdf.fonttype":42})
INK="#0b0b0b"; MUTE="#52514e"; GRID="#e1e0d9"
BLUE="#2a78d6"; ORANGE="#eb6834"; GREEN="#1baf7a"

def style(ax):
    ax.grid(axis="y",color=GRID,lw=0.5); ax.set_axisbelow(True)
    for s in ("top","right"): ax.spines[s].set_visible(False)
    ax.tick_params(length=2,pad=2)

def logy(ax,ticks,lo,hi):
    ax.set_yscale("log"); ax.set_ylim(lo,hi)
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FixedFormatter([f"{t:g}" for t in ticks]))
    ax.yaxis.set_minor_locator(NullLocator())

# ---------------- Fig. 2: schema scaling ----------------
x=[10,50,120]
T=rows("table1_schema_scaling.csv")
def sysrow(name, key): return [float(r[key]) for r in T if r["system"]==name]
STYLE=[("Proposed MCP+RAG","Proposed MCP+RAG",BLUE,"o","-"),("MCP-Only (no RAG)","MCP-Only (no RAG)",ORANGE,"s","--"),
       ("LinkAlign","LinkAlign",GREEN,"^","-."),("RSL-SQL","RSL-SQL","#eda100","D",":"),
       ("Ungoverned Baseline","Ungoverned","#e87ba4","v",(0,(5,1,1,1)))]
S=[(lab,c,m,ls,sysrow(key,"ex_pct"),sysrow(key,"shr_pct")) for key,lab,c,m,ls in STYLE]
fig,(a,b)=plt.subplots(1,2,figsize=(3.5,2.0))
for name,c,m,ls,ex,shr in S:
    prop=name.startswith("Proposed"); lw=2.0 if prop else 1.3
    kw=dict(color=c,marker=m,ls=ls,lw=lw,ms=4.5,mec="white",mew=0.6,zorder=3)
    a.plot(x,ex,label=name,**kw)
    if prop:   # zero cannot be drawn on a log axis: hollow marker at the axis floor
        b.plot(x[1:],shr[1:],**kw)
        b.plot([10,50],[0.1,0.1],color=c,ls=ls,lw=lw,zorder=2)
        b.plot([10],[0.1],marker=m,ms=4.5,mfc="white",mec=c,mew=1.0,zorder=4)
    else: b.plot(x,shr,**kw)
for ax in (a,b):
    ax.set_xticks(x); style(ax); ax.set_xlim(0,130)
a.set_ylim(40,100); a.set_ylabel("Execution accuracy (%)",labelpad=1)
logy(b,[0.1,0.3,1,3,10,30],0.07,60); b.set_ylabel("SHR (%, log scale)",labelpad=1)
a.set_xlabel("(a) Tables in schema",labelpad=1); b.set_xlabel("(b) Tables in schema",labelpad=1)
h,l=a.get_legend_handles_labels()
fig.legend(h,l,loc="upper center",ncol=3,frameon=False,fontsize=6.6,handlelength=2.4,columnspacing=0.9,
           handletextpad=0.4,bbox_to_anchor=(0.5,1.0),labelcolor=INK)
fig.subplots_adjust(left=0.115,right=0.99,bottom=0.17,top=0.82,wspace=0.42)
fig.savefig(out+"/fig_scaling.pdf"); plt.close(fig)

# ---------------- Fig. 3: CSS sensitivity (four single-axis panels) ----------------
th=series("fig3_css_sensitivity_theta.csv","theta"); shr_t=series("fig3_css_sensitivity_theta.csv","shr_pct")
ser_t=series("fig3_css_sensitivity_theta.csv","ser_pct")
k=series("fig3_css_sensitivity_k.csv","k"); shr_k=series("fig3_css_sensitivity_k.csv","shr_pct")
tok=series("fig3_css_sensitivity_k.csv","relative_prompt_tokens_pct")
fig,ax=plt.subplots(1,4,figsize=(7.16,1.45))
P=[(ax[0],th,shr_t,ORANGE,"o","SHR (%, log scale)",r"(a) Matching threshold $\theta$",0.62),
   (ax[1],th,ser_t,BLUE,"s","SER (%)",r"(b) Matching threshold $\theta$",0.62),
   (ax[2],k,shr_k,ORANGE,"o","SHR (%, log scale)",r"(c) Retrieval budget $k$",40),
   (ax[3],k,tok,GREEN,"^","Prompt tokens (%)",r"(d) Retrieval budget $k$",40)]
for a_,xs,ys,c,m,yl,xl,sel in P:
    a_.axvline(sel,color=MUTE,ls=":",lw=0.9,zorder=1)
    a_.plot(xs,ys,color=c,marker=m,lw=1.5,ms=4.5,mec="white",mew=0.6,zorder=3)
    a_.set_ylabel(yl,labelpad=1); a_.set_xlabel(xl,labelpad=1); style(a_)
for a_ in ax[:2]: a_.set_xticks([0.45,0.55,0.65,0.75]); a_.set_xlim(0.43,0.77)
for a_ in ax[2:]: a_.set_xticks([10,20,40,60,80]); a_.set_xlim(5,85)
logy(ax[0],[0.2,0.5,1,2,4],0.2,4); logy(ax[2],[0.2,0.5,1,2,4],0.2,4)
ax[1].set_ylim(92,100); ax[3].set_ylim(40,180)
# dotted line = selected value (labelled once per hyperparameter, in an empty region)
ax[0].text(0.628,2.9,r"selected $\theta{=}0.62$",fontsize=6.5,color=MUTE,ha="left",va="center")
ax[2].text(42,2.9,r"selected $k{=}40$",fontsize=6.5,color=MUTE,ha="left",va="center")
fig.subplots_adjust(left=0.055,right=0.995,bottom=0.27,top=0.96,wspace=0.42)
fig.savefig(out+"/fig_css_sensitivity.pdf"); plt.close(fig)

# ---------------- Fig. 4: schema evolution ----------------
cats=["None","Column\nrename","Table\nrename","Table\nmerge"]
ex=series("fig4_schema_evolution.csv","ex_pct"); shr=series("fig4_schema_evolution.csv","shr_pct"); i=np.arange(4)
fig,(a,b)=plt.subplots(1,2,figsize=(3.5,1.8))
a.bar(i,ex,0.6,color=BLUE,zorder=3)
for xi,v in zip(i,ex): a.text(xi,v+1.5,f"{v}",ha="center",va="bottom",fontsize=7,color=INK,
                              bbox=dict(fc="white",ec="none",pad=0.6))
a.set_ylim(0,108); a.set_yticks([0,25,50,75,100]); a.set_ylabel("Execution accuracy (%)",labelpad=1)
# SHR spans two orders of magnitude -> log axis; points (not bars), since a log axis has no zero baseline
b.axhline(15,color=MUTE,ls=":",lw=0.9,zorder=1)
b.plot(i,shr,color=ORANGE,ls="none",marker="o",ms=5.5,mec="white",mew=0.6,zorder=3)
for xi,v,va,f in zip(i,shr,["center","center","top","bottom"],[1,1,0.97,1.06]):
    b.text(xi+0.17,v*f,f"{v}",ha="left",va=va,fontsize=7,color=INK)
b.text(-0.45,17.0,"15% risk threshold",fontsize=6.5,color=MUTE,ha="left",va="bottom")
logy(b,[0.3,1,3,10,30],0.18,45); b.set_ylabel("SHR (%, log scale)",labelpad=1)
for ax_,lab in ((a,"(a) Perturbation"),(b,"(b) Perturbation")):
    ax_.set_xticks(i); ax_.set_xticklabels(cats,fontsize=6.5,color=INK)
    ax_.set_xlim(-0.55,3.55 if ax_ is a else 3.85)
    ax_.set_xlabel(lab,labelpad=1); style(ax_); ax_.tick_params(axis="x",length=0)
fig.subplots_adjust(left=0.115,right=0.99,bottom=0.3,top=0.95,wspace=0.42)
fig.savefig(out+"/fig_evolution.pdf"); plt.close(fig)
