# infra

Deployment configuration for the AWS environment used in the paper (EC2, Lambda,
API Gateway, Aurora PostgreSQL) belongs in this folder: instance types, Lambda memory
and timeout settings, VPC and IAM configuration, and the model-serving setup.

No configuration is included in this release yet.
