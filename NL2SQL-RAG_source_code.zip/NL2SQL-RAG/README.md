# NL2SQL-RAG

Companion repository for the paper

> C. K. Mankala and M. Giacobbe, "Making Enterprise NL2SQL Reliable: MCP, Constrained Decoding, and Hybrid RAG," in *Proc. Int. Conf. on Artificial Intelligence, Computer, Data Sciences and Applications (ACDSA 2027)*, Rio de Janeiro, Brazil, Feb. 2027.

The paper presents an enterprise NL2SQL pipeline in which the LLM never writes SQL:

1. **Semantic orchestration**: entropy-guided sparse–dense hybrid retrieval and Collective Schema Subsetting (CSS) select the part of the schema a question needs.
2. **Protocol gateway**: an MCP-style gateway constrains decoding with JSON-schema masks, so the model emits only valid tool invocations.
3. **Deterministic execution**: an AST compiler turns each validated invocation into parameterized ANSI SQL.

## What this repository contains

| Path | Contents |
|---|---|
| `src/nl2sql_rag/` | Reference implementation of the pipeline (see the module map below) |
| `examples/demo.py` | End-to-end run on an in-memory SQLite database; needs no model weights |
| `tests/` | Unit and end-to-end tests |
| `results/` | The numbers reported in the paper, one CSV per table or figure |
| `figures/` | Script that regenerates Figs. 2–4 from `results/`, and the generated PDFs |
| `benchmark/` | Notes on the evaluation set; the benchmark itself is not included yet |
| `infra/` | Placeholder for the AWS deployment configuration |

### Scope of the code

`src/nl2sql_rag/` is a **reference implementation of the method described in the paper**. It is written to make each mechanism inspectable and runnable on a laptop:

- The dense encoder defaults to a dependency-free hashing encoder, and the demo replaces the LLM with a deterministic scripted scorer. A real bi-encoder and a real model plug in through the documented interfaces (`HybridIndex(embedder=...)`, `Pipeline(logits_factory=...)`, `gateway/hf.py`).
- The tool catalog has two generic tools (`select_rows`, `aggregate`) generated from the schema. It is not the catalog engineered for the paper's benchmark.
- The gateway speaks the JSON-RPC 2.0 message shapes that MCP uses for `initialize`, `tools/list` and `tools/call`; it is not a full MCP implementation.
- Orchestration is a plain retry loop with the same nodes and state as the paper's LangGraph graph.

The repository does **not** contain the benchmark, the baselines, or the experiment harness that produced the numbers in `results/`, so running this code does not reproduce the paper's tables. The CSV files record the reported results.

## Quick start

```bash
pip install -r requirements.txt
python examples/demo.py     # three questions, including one where the mask blocks a non-existent column
python -m pytest            # 15 tests
python figures/make_figures.py
```

## Module map

| Module | Paper section | What it implements |
|---|---|---|
| `catalog.py` | III | Tables, columns, foreign keys, FK graph, schema chunks |
| `retrieval/hybrid.py` | III-A1, Eqs. 1–3 | Cosine and BM25 scoring, min–max normalization, entropy-adaptive weight α |
| `retrieval/css.py` | III-A2, Alg. 1 | Virtual-schema grounding with threshold θ, de-duplication, top-k, h-hop FK expansion, negative constraints |
| `gateway/automaton.py` | III-B | Incremental validity tracker (regular-expression derivatives) |
| `gateway/schema.py` | III-B | JSON Schema → automaton for canonical JSON tool calls |
| `gateway/masking.py` | III-B, Eqs. 4–5 | Binary mask M(x_t), masked distribution, greedy decoding with the paper's tie-break |
| `gateway/tools.py` | III-D | Tool schemas whose identifier parameters are enumerations over the grounded context |
| `gateway/server.py` | III-B | JSON-RPC tool server: schema validation, compilation, execution |
| `gateway/hf.py` | III-B | Optional Hugging Face `LogitsProcessor` adapter (not covered by the tests) |
| `compiler/glsl.py` | III-C | Global pruning over FK paths, trie-based local alignment, AST, parameterized SQL |
| `orchestration/pipeline.py` | III-E | State ⟨M_hist, I_intent, T_params, E_status⟩ and the retrieve–generate–validate cycle |
| `eval/metrics.py` | IV-C | EX, VES, SER, SHR |
| `eval/stats.py` | IV-C | Wilson and Newcombe intervals; the tests reproduce the intervals printed in the paper |

### Supported SQL fragment

`SELECT` over one or more FK-connected tables with inner joins, conjunctive `WHERE` filters (`=`, `<>`, `<`, `<=`, `>`, `>=`, `LIKE`), `GROUP BY` with `COUNT`/`SUM`/`AVG`/`MIN`/`MAX`, `ORDER BY`, and `LIMIT`. Sub-queries, set operations, `HAVING`, outer joins and window functions are outside the catalog; such a question returns no executable SQL.

### What the mask guarantees

Every decoded tool call conforms to the registered JSON schema, and every identifier-valued parameter is drawn from the enumeration built from the grounded context. Filter values are free text or integers and are passed to the database as bound parameters, never interpolated into SQL. The mask does not guarantee that the chosen column is the semantically right one.

## Reported results

| File | Paper item |
|---|---|
| `results/table1_schema_scaling.csv` | Table I: EX, VES, SER and SHR for five systems at 10, 50 and 120 tables |
| `results/table2_ablation.csv` | Table II: ablation at 120 tables |
| `results/table3_latency.csv` | Table III: median stage latency at 120 tables |
| `results/fig3_css_sensitivity_theta.csv`, `results/fig3_css_sensitivity_k.csv` | Fig. 3: CSS hyperparameter sensitivity |
| `results/fig4_schema_evolution.csv` | Fig. 4: EX and SHR under schema perturbation |

## Data

The evaluation set is derived from two public benchmarks, which must be obtained from their original sources:

- BIRD: https://bird-bench.github.io
- Spider: https://yale-lily.github.io/spider

## Citation

See `CITATION.cff`.

## Acknowledgment

This work used the Augie High-Performance Computing cluster at Villanova University, funded by National Science Foundation award 2018933.
